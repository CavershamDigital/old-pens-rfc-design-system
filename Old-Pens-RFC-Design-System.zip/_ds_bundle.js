/* @ds-bundle: {"format":4,"namespace":"OldPensRFCDesignSystem_560a26","components":[{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"Tag","sourcePath":"components/display/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/forms/IconButton.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/display/Badge.jsx":"fa85b9fba48e","components/display/Card.jsx":"1ba6b432109f","components/display/Tag.jsx":"7d7c6d53605d","components/feedback/Dialog.jsx":"2d9d07c3fbeb","components/feedback/Toast.jsx":"56f76060fd04","components/feedback/Tooltip.jsx":"b7a0be2483db","components/forms/Button.jsx":"822a89585bad","components/forms/Checkbox.jsx":"5a38563a1929","components/forms/IconButton.jsx":"c00e87778c49","components/forms/Input.jsx":"2fedb39ebb19","components/forms/Radio.jsx":"f08d56905695","components/forms/Select.jsx":"259b4d17ef5a","components/forms/Switch.jsx":"425258fe5bc6","components/navigation/Tabs.jsx":"fc3b60446261","ui_kits/club-site/FixturesScreen.jsx":"948a780608b5","ui_kits/club-site/Header.jsx":"9f29021b2241","ui_kits/club-site/HomeScreen.jsx":"25807bb7bad9","ui_kits/club-site/JoinScreen.jsx":"91d849bb5b98"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.OldPensRFCDesignSystem_560a26 = window.OldPensRFCDesignSystem_560a26 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/display/Badge.jsx
try { (() => {
function Badge({
  tone = 'navy',
  children,
  style
}) {
  const t = {
    navy: {
      bg: 'var(--surface-inverse)',
      fg: 'var(--text-inverse)'
    },
    blue: {
      bg: 'var(--action-primary)',
      fg: '#fff'
    },
    gold: {
      bg: 'var(--accent)',
      fg: 'var(--text-on-gold)'
    },
    red: {
      bg: 'var(--danger)',
      fg: '#fff'
    },
    neutral: {
      bg: 'var(--neutral-100)',
      fg: 'var(--text-muted)'
    }
  }[tone];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      padding: '3px 10px',
      borderRadius: 'var(--radius-sm)',
      background: t.bg,
      color: t.fg,
      fontFamily: 'var(--font-headline)',
      fontWeight: 700,
      fontSize: '11px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
function Card({
  title,
  kicker,
  footer,
  accent = false,
  image,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-card)',
      overflow: 'hidden',
      borderTop: accent ? 'var(--border-width-heavy) solid var(--accent)' : 'none',
      fontFamily: 'var(--font-body)',
      ...style
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      display: 'block',
      width: '100%',
      height: '160px',
      objectFit: 'cover'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-5)'
    }
  }, kicker && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-headline)',
      fontWeight: 600,
      fontSize: '11px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--accent)',
      marginBottom: '6px'
    }
  }, kicker), title && /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--text-lg)',
      marginBottom: '8px'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 400,
      fontSize: '14px',
      color: 'var(--text-body)',
      lineHeight: 'var(--leading-body)'
    }
  }, children)), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px var(--space-5)',
      borderTop: '1px solid var(--border-subtle)',
      fontSize: '13px',
      fontWeight: 400,
      color: 'var(--text-muted)'
    }
  }, footer));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/Tag.jsx
try { (() => {
function Tag({
  children,
  onRemove,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      padding: '4px 10px',
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--border-subtle)',
      background: 'var(--surface-card)',
      color: 'var(--text-body)',
      fontFamily: 'var(--font-body)',
      fontWeight: 400,
      fontSize: '13px',
      ...style
    }
  }, children, onRemove && /*#__PURE__*/React.createElement("button", {
    onClick: onRemove,
    "aria-label": "Remove",
    style: {
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      color: 'var(--text-muted)',
      fontSize: '12px',
      padding: 0,
      lineHeight: 1
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function Toast({
  tone = 'info',
  title,
  onClose,
  children,
  style
}) {
  const t = {
    info: {
      bar: 'var(--action-primary)'
    },
    success: {
      bar: 'var(--accent)'
    },
    error: {
      bar: 'var(--danger)'
    }
  }[tone];
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '12px',
      maxWidth: '380px',
      background: 'var(--surface-inverse)',
      color: 'var(--text-inverse)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-raised)',
      padding: '14px 16px',
      fontFamily: 'var(--font-body)',
      position: 'relative',
      overflow: 'hidden',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      bottom: 0,
      width: '4px',
      background: t.bar
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      paddingLeft: '6px'
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-headline)',
      fontWeight: 700,
      fontSize: '13px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      marginBottom: '2px'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 300,
      fontSize: '13px',
      lineHeight: 'var(--leading-snug)'
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      border: 'none',
      background: 'none',
      color: 'var(--text-inverse)',
      cursor: 'pointer',
      fontSize: '13px',
      padding: 0,
      opacity: .7
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
const {
  useState
} = React;
function Tooltip({
  label,
  children,
  style
}) {
  const [show, setShow] = useState(false);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-block',
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      bottom: 'calc(100% + 8px)',
      left: '50%',
      transform: 'translateX(-50%)',
      whiteSpace: 'nowrap',
      background: 'var(--neutral-900)',
      color: '#fff',
      fontFamily: 'var(--font-body)',
      fontWeight: 400,
      fontSize: '12px',
      padding: '6px 10px',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-card)',
      zIndex: 100
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const [press, setPress] = useState(false);
  const sizes = {
    sm: {
      padding: '7px 14px',
      fontSize: '12px'
    },
    md: {
      padding: '10px 22px',
      fontSize: '13px'
    },
    lg: {
      padding: '14px 30px',
      fontSize: '15px'
    }
  };
  const v = {
    primary: {
      bg: 'var(--action-primary)',
      bgH: 'var(--action-primary-hover)',
      bgA: 'var(--action-primary-active)',
      fg: '#fff',
      bd: 'transparent'
    },
    gold: {
      bg: 'var(--accent)',
      bgH: 'var(--accent-strong)',
      bgA: 'var(--accent-strong)',
      fg: 'var(--text-on-gold)',
      bd: 'transparent'
    },
    secondary: {
      bg: hover ? 'rgba(36,89,157,.08)' : 'transparent',
      bgH: 'rgba(36,89,157,.08)',
      bgA: 'rgba(36,89,157,.15)',
      fg: 'var(--action-primary)',
      bd: 'var(--action-primary)'
    },
    ghost: {
      bg: 'transparent',
      bgH: 'rgba(36,89,157,.08)',
      bgA: 'rgba(36,89,157,.15)',
      fg: 'var(--action-primary)',
      bd: 'transparent'
    },
    danger: {
      bg: 'var(--danger)',
      bgH: 'var(--danger-strong)',
      bgA: 'var(--danger-strong)',
      fg: '#fff',
      bd: 'transparent'
    }
  }[variant];
  const bg = disabled ? 'var(--border-subtle)' : press ? v.bgA : hover ? v.bgH : v.bg;
  return /*#__PURE__*/React.createElement("button", _extends({
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      fontFamily: 'var(--font-headline)',
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      border: `1px solid ${disabled ? 'transparent' : v.bd}`,
      borderRadius: 'var(--radius-sm)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      color: disabled ? 'var(--text-muted)' : v.fg,
      background: bg,
      transition: 'background var(--transition-fast)',
      width: fullWidth ? '100%' : undefined,
      ...sizes[size],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open = false,
  title,
  onClose,
  actions,
  children,
  style
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(20,39,76,.55)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    onClick: e => e.stopPropagation(),
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-raised)',
      maxWidth: '440px',
      width: '100%',
      overflow: 'hidden',
      fontFamily: 'var(--font-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '18px 24px',
      background: 'var(--surface-inverse)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      color: 'var(--text-inverse)',
      fontSize: '16px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)'
    }
  }, title), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Close",
    style: {
      border: 'none',
      background: 'none',
      color: 'var(--text-inverse)',
      cursor: 'pointer',
      fontSize: '16px',
      padding: 0
    }
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px',
      fontWeight: 400,
      fontSize: '14px',
      lineHeight: 'var(--leading-body)'
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 24px',
      borderTop: '1px solid var(--border-subtle)',
      display: 'flex',
      justifyContent: 'flex-end',
      gap: '10px'
    }
  }, actions || /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    onClick: onClose
  }, "OK"))));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked = false,
  disabled = false,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontFamily: 'var(--font-body)',
      fontWeight: 400,
      fontSize: '14px',
      color: disabled ? 'var(--text-muted)' : 'var(--text-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      width: '18px',
      height: '18px',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked),
    style: {
      position: 'absolute',
      inset: 0,
      opacity: 0,
      margin: 0,
      cursor: 'inherit'
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 'var(--radius-sm)',
      border: `1px solid ${checked ? 'var(--action-primary)' : 'var(--neutral-600)'}`,
      background: disabled ? 'var(--neutral-100)' : checked ? 'var(--action-primary)' : 'var(--surface-card)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#fff',
      fontSize: '12px',
      fontWeight: 700,
      transition: 'background var(--transition-fast)'
    }
  }, checked ? '✓' : '')), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
function IconButton({
  label,
  variant = 'ghost',
  size = 'md',
  disabled = false,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const dim = {
    sm: 28,
    md: 36,
    lg: 44
  }[size];
  const v = {
    primary: {
      bg: 'var(--action-primary)',
      bgH: 'var(--action-primary-hover)',
      fg: '#fff'
    },
    gold: {
      bg: 'var(--accent)',
      bgH: 'var(--accent-strong)',
      fg: 'var(--text-on-gold)'
    },
    ghost: {
      bg: hover ? 'rgba(36,89,157,.10)' : 'transparent',
      bgH: 'rgba(36,89,157,.10)',
      fg: 'var(--action-primary)'
    }
  }[variant];
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": label,
    title: label,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: dim,
      height: dim,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: 'none',
      borderRadius: 'var(--radius-sm)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      background: disabled ? 'var(--border-subtle)' : hover ? v.bgH : v.bg,
      color: disabled ? 'var(--text-muted)' : v.fg,
      fontSize: dim * 0.5,
      transition: 'background var(--transition-fast)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
function Input({
  label,
  hint,
  error,
  type = 'text',
  disabled = false,
  style,
  ...rest
}) {
  const [focus, setFocus] = useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-body)'
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-headline)',
      fontWeight: 600,
      fontSize: '12px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--text-heading)',
      marginBottom: '6px'
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      display: 'block',
      width: '100%',
      boxSizing: 'border-box',
      padding: '10px 12px',
      fontFamily: 'var(--font-body)',
      fontWeight: 400,
      fontSize: '14px',
      color: 'var(--text-body)',
      background: disabled ? 'var(--neutral-100)' : 'var(--surface-card)',
      border: `1px solid ${error ? 'var(--danger)' : focus ? 'var(--action-primary)' : 'var(--border-subtle)'}`,
      borderRadius: 'var(--radius-sm)',
      outline: 'none',
      boxShadow: focus ? 'var(--shadow-focus)' : 'none',
      transition: 'box-shadow var(--transition-fast)',
      ...style
    }
  }, rest)), error ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: '12px',
      fontWeight: 400,
      color: 'var(--danger-strong)',
      marginTop: '4px'
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: '12px',
      fontWeight: 400,
      color: 'var(--text-muted)',
      marginTop: '4px'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  label,
  name,
  value,
  checked = false,
  disabled = false,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontFamily: 'var(--font-body)',
      fontWeight: 400,
      fontSize: '14px',
      color: disabled ? 'var(--text-muted)' : 'var(--text-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      width: '18px',
      height: '18px',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    disabled: disabled,
    onChange: () => onChange && onChange(value),
    style: {
      position: 'absolute',
      inset: 0,
      opacity: 0,
      margin: 0,
      cursor: 'inherit'
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: '50%',
      border: `1px solid ${checked ? 'var(--action-primary)' : 'var(--neutral-600)'}`,
      background: disabled ? 'var(--neutral-100)' : 'var(--surface-card)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: '10px',
      height: '10px',
      borderRadius: '50%',
      background: 'var(--action-primary)'
    }
  }))), label);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
function Select({
  label,
  options = [],
  disabled = false,
  style,
  ...rest
}) {
  const [focus, setFocus] = useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-body)'
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-headline)',
      fontWeight: 600,
      fontSize: '12px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--text-heading)',
      marginBottom: '6px'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      display: 'block',
      width: '100%',
      appearance: 'none',
      WebkitAppearance: 'none',
      padding: '10px 32px 10px 12px',
      fontFamily: 'var(--font-body)',
      fontWeight: 400,
      fontSize: '14px',
      color: 'var(--text-body)',
      background: disabled ? 'var(--neutral-100)' : 'var(--surface-card)',
      border: `1px solid ${focus ? 'var(--action-primary)' : 'var(--border-subtle)'}`,
      borderRadius: 'var(--radius-sm)',
      outline: 'none',
      boxShadow: focus ? 'var(--shadow-focus)' : 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, rest), options.map(o => typeof o === 'string' ? /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o) : /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      right: '12px',
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none',
      color: 'var(--text-muted)',
      fontSize: '10px'
    }
  }, "\u25BE")));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked = false,
  disabled = false,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontFamily: 'var(--font-body)',
      fontWeight: 400,
      fontSize: '14px',
      color: disabled ? 'var(--text-muted)' : 'var(--text-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    role: "switch",
    "aria-checked": checked,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: '38px',
      height: '22px',
      borderRadius: 'var(--radius-pill)',
      flexShrink: 0,
      position: 'relative',
      background: disabled ? 'var(--border-subtle)' : checked ? 'var(--action-primary)' : 'var(--neutral-600)',
      transition: 'background var(--transition-base)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '3px',
      left: checked ? '19px' : '3px',
      width: '16px',
      height: '16px',
      borderRadius: '50%',
      background: '#fff',
      transition: 'left var(--transition-base)'
    }
  })), label);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  tabs = [],
  active,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: 'flex',
      gap: '4px',
      borderBottom: '2px solid var(--border-subtle)',
      fontFamily: 'var(--font-headline)',
      ...style
    }
  }, tabs.map(t => {
    const sel = t === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t,
      role: "tab",
      "aria-selected": sel,
      onClick: () => onChange && onChange(t),
      style: {
        padding: '10px 18px',
        border: 'none',
        background: 'none',
        cursor: 'pointer',
        fontFamily: 'inherit',
        fontWeight: sel ? 700 : 500,
        fontSize: '13px',
        textTransform: 'uppercase',
        letterSpacing: 'var(--tracking-caps)',
        color: sel ? 'var(--text-heading)' : 'var(--text-muted)',
        boxShadow: sel ? 'inset 0 -3px 0 var(--accent)' : 'none',
        marginBottom: '-2px',
        transition: 'color var(--transition-fast)'
      }
    }, t);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/club-site/FixturesScreen.jsx
try { (() => {
function FixturesScreen() {
  const {
    Tabs,
    Badge,
    Card
  } = window.OldPensRFCDesignSystem_560a26;
  const [tab, setTab] = React.useState('Fixtures');
  const fixtures = [{
    date: 'Sat 12 Sep',
    opp: "St Peter's",
    ha: 'Home',
    ko: '14:30'
  }, {
    date: 'Sat 19 Sep',
    opp: 'Dinas Powys',
    ha: 'Away',
    ko: '14:30'
  }, {
    date: 'Sat 26 Sep',
    opp: 'Wenvoe',
    ha: 'Home',
    ko: '14:30'
  }, {
    date: 'Sat 3 Oct',
    opp: 'Cowbridge',
    ha: 'Away',
    ko: '14:00'
  }];
  const results = [{
    date: 'Sat 25 Apr',
    opp: 'Llandaff North',
    ha: 'Home',
    f: 24,
    a: 17
  }, {
    date: 'Sat 18 Apr',
    opp: 'Fairwater',
    ha: 'Away',
    f: 12,
    a: 31
  }, {
    date: 'Sat 11 Apr',
    opp: 'Cardiff Quins',
    ha: 'Home',
    f: 38,
    a: 10
  }];
  const rowStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: 16,
    padding: '16px 20px',
    borderBottom: '1px solid var(--border-subtle)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 900,
      margin: '0 auto',
      padding: '40px 24px 0'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-2xl)',
      textTransform: 'uppercase',
      marginBottom: 24
    }
  }, "Fixtures & results"), /*#__PURE__*/React.createElement(Tabs, {
    tabs: ['Fixtures', 'Results'],
    active: tab,
    onChange: setTab
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: '0 0 var(--radius-md) var(--radius-md)',
      boxShadow: 'var(--shadow-card)'
    }
  }, tab === 'Fixtures' ? fixtures.map(f => /*#__PURE__*/React.createElement("div", {
    key: f.date,
    style: rowStyle
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 96,
      fontWeight: 300,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, f.date), /*#__PURE__*/React.createElement(Badge, {
    tone: f.ha === 'Home' ? 'gold' : 'navy'
  }, f.ha), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-headline)',
      fontWeight: 700,
      fontSize: 15,
      textTransform: 'uppercase'
    }
  }, "Old Penarthians vs ", f.opp), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontWeight: 300,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "KO ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-number)',
      fontSize: 19,
      color: 'var(--text-heading)'
    }
  }, f.ko)))) : results.map(r => /*#__PURE__*/React.createElement("div", {
    key: r.date,
    style: rowStyle
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 96,
      fontWeight: 300,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, r.date), /*#__PURE__*/React.createElement(Badge, {
    tone: r.ha === 'Home' ? 'gold' : 'navy'
  }, r.ha), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-headline)',
      fontWeight: 700,
      fontSize: 15,
      textTransform: 'uppercase'
    }
  }, "Old Penarthians vs ", r.opp), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-number)',
      fontSize: 26,
      color: r.f > r.a ? 'var(--action-primary)' : 'var(--danger-strong)'
    }
  }, r.f, " \u2013 ", r.a), /*#__PURE__*/React.createElement(Badge, {
    tone: r.f > r.a ? 'blue' : 'red'
  }, r.f > r.a ? 'Won' : 'Lost'))))));
}
Object.assign(window, {
  FixturesScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/club-site/FixturesScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/club-site/Header.jsx
try { (() => {
function Header({
  screen,
  onNav
}) {
  const links = ['Home', 'Fixtures', 'Join'];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      background: 'var(--surface-inverse)',
      color: 'var(--text-inverse)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1120,
      margin: '0 auto',
      padding: '0 24px',
      display: 'flex',
      alignItems: 'center',
      gap: 20,
      height: 72
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/OPRFC-Final-Crest-Only.png",
    alt: "OPRFC crest",
    style: {
      width: 48,
      height: 48
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-clubname)',
      fontSize: 24,
      lineHeight: 1
    }
  }, "Old Penarthians R.F.C"), /*#__PURE__*/React.createElement("nav", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 8
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav(l);
    },
    style: {
      fontFamily: 'var(--font-headline)',
      fontWeight: 600,
      fontSize: 12,
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: screen === l ? 'var(--accent-bright)' : 'var(--text-inverse)',
      textDecoration: 'none',
      padding: '10px 14px',
      boxShadow: screen === l ? 'inset 0 -3px 0 var(--accent)' : 'none'
    }
  }, l)))));
}
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--surface-inverse)',
      color: 'var(--text-inverse)',
      marginTop: 64
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1120,
      margin: '0 auto',
      padding: '28px 24px',
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/OPRFC-Final-Crest-Only.png",
    alt: "",
    style: {
      width: 36,
      height: 36
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 300,
      opacity: .85
    }
  }, "Old Penarthians RFC \xB7 Cwrt-y-Vil Playing Fields, St. Marks Road, Penarth, CF64 3PF")));
}
Object.assign(window, {
  Header,
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/club-site/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/club-site/HomeScreen.jsx
try { (() => {
function HomeScreen({
  onNav
}) {
  const {
    Button,
    Card,
    Badge
  } = window.OldPensRFCDesignSystem_560a26;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      height: 420,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/old-penarthians-team.jpg",
    alt: "Old Pens in action",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(90deg, rgba(20,39,76,.88) 0%, rgba(20,39,76,.55) 45%, rgba(20,39,76,.15) 100%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 1120,
      margin: '0 auto',
      padding: '0 24px',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-headline)',
      fontWeight: 600,
      fontSize: 13,
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--accent-bright)'
    }
  }, "Est. Penarth \xB7 Rugby for everyone"), /*#__PURE__*/React.createElement("h1", {
    style: {
      color: '#fff',
      fontSize: 'var(--text-3xl)',
      textTransform: 'uppercase',
      maxWidth: '14ch'
    }
  }, "Mon the Pens"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-inverse)',
      fontWeight: 300,
      fontSize: 16,
      maxWidth: '44ch',
      margin: 0
    }
  }, "Community rugby at Cwrt-y-Vil \u2014 minis on Sunday mornings, seniors on Saturday afternoons."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "gold",
    size: "lg",
    onClick: () => onNav('Join')
  }, "Join the club"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    style: {
      color: '#fff',
      borderColor: '#fff'
    },
    onClick: () => onNav('Fixtures')
  }, "Fixtures")))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-raised)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1120,
      margin: '0 auto',
      padding: '20px 24px',
      display: 'flex',
      alignItems: 'center',
      gap: 24,
      color: 'var(--text-inverse)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "gold"
  }, "Next fixture"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-headline)',
      fontWeight: 700,
      fontSize: 18,
      textTransform: 'uppercase'
    }
  }, "Old Penarthians"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-number)',
      fontSize: 30,
      color: 'var(--accent-bright)'
    }
  }, "VS"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-headline)',
      fontWeight: 700,
      fontSize: 18,
      textTransform: 'uppercase'
    }
  }, "St Peter's")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      fontWeight: 300,
      fontSize: 14
    }
  }, "Sat 12 Sep \xB7 KO ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-number)',
      fontSize: 20
    }
  }, "14:30"), " \xB7 Cwrt-y-Vil"))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1120,
      margin: '0 auto',
      padding: '48px 24px 0'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 'var(--text-xl)',
      textTransform: 'uppercase',
      marginBottom: 24
    }
  }, "Club news"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(Card, {
    image: "../../assets/old-penarthians-team.jpg",
    kicker: "Seniors",
    title: "Pre-season friendly confirmed",
    footer: "2 Sep 2026"
  }, "The 1st XV host St Peter's in the final warm-up before the league opener."), /*#__PURE__*/React.createElement(Card, {
    accent: true,
    kicker: "Minis & juniors",
    title: "Registration Sunday",
    footer: "30 Aug 2026"
  }, "New season sign-on at the clubhouse from 9:30am \u2014 new players always welcome."), /*#__PURE__*/React.createElement(Card, {
    kicker: "Clubhouse",
    title: "Kit shop open",
    footer: "28 Aug 2026"
  }, "This season's playing and training range is now available to order."))));
}
Object.assign(window, {
  HomeScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/club-site/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/club-site/JoinScreen.jsx
try { (() => {
function JoinScreen() {
  const {
    Input,
    Select,
    Checkbox,
    Radio,
    Switch,
    Button,
    Dialog,
    Toast
  } = window.OldPensRFCDesignSystem_560a26;
  const [section, setSection] = React.useState('seniors');
  const [conduct, setConduct] = React.useState(false);
  const [news, setNews] = React.useState(true);
  const [open, setOpen] = React.useState(false);
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '0 auto',
      padding: '40px 24px 0'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-2xl)',
      textTransform: 'uppercase'
    }
  }, "Join the club"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 300,
      fontSize: 14,
      color: 'var(--text-muted)',
      margin: '10px 0 28px'
    }
  }, "Minis, juniors, seniors and social members \u2014 everyone is welcome down the Pens."), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-card)',
      padding: 32,
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "First name",
    placeholder: "Dai"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Surname",
    placeholder: "Evans"
  })), /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    type: "email",
    placeholder: "you@example.com",
    hint: "Used for club communications only."
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Age group",
    options: ['Seniors', 'Youth', 'Under 12s', 'Under 10s', 'Under 8s', 'Minis']
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Radio, {
    name: "sec",
    value: "seniors",
    label: "Playing member",
    checked: section === 'seniors',
    onChange: setSection
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "sec",
    value: "social",
    label: "Social member",
    checked: section === 'social',
    onChange: setSection
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "sec",
    value: "volunteer",
    label: "Volunteer",
    checked: section === 'volunteer',
    onChange: setSection
  })), /*#__PURE__*/React.createElement(Checkbox, {
    label: "I agree to the club code of conduct",
    checked: conduct,
    onChange: setConduct
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Email me fixture updates",
    checked: news,
    onChange: setNews
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    variant: "gold",
    size: "lg",
    disabled: !conduct,
    onClick: () => setOpen(true)
  }, "Submit application"))), sent && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      bottom: 24,
      right: 24,
      zIndex: 50
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "success",
    title: "Application sent",
    onClose: () => setSent(false)
  }, "We'll be in touch before the weekend.")), /*#__PURE__*/React.createElement(Dialog, {
    open: open,
    title: "Confirm application",
    onClose: () => setOpen(false),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setOpen(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      onClick: () => {
        setOpen(false);
        setSent(true);
      }
    }, "Confirm"))
  }, "Send your membership application to the club secretary?"));
}
Object.assign(window, {
  JoinScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/club-site/JoinScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
