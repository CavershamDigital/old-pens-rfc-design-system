Input — labelled text field; gold focus ring, red error state.

```jsx
<Input label="Email" placeholder="you@example.com" hint="We'll never share it." />
<Input label="Postcode" error="Required" />
```
