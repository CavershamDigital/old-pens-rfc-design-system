Button — uppercase Montserrat Bold action button; use `primary` (club blue) for main actions, `gold` for standout brand moments, `danger` (red) sparingly.

```jsx
<Button variant="primary" size="md" onClick={fn}>Join the club</Button>
```

Variants: primary | gold | secondary (outline) | ghost | danger. Sizes sm/md/lg. `fullWidth` stretches to container.
