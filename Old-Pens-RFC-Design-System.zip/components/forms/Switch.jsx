import React from 'react';
export function Switch({label,checked=false,disabled=false,onChange,style}){
  return <label style={{display:'inline-flex',alignItems:'center',gap:'10px',cursor:disabled?'not-allowed':'pointer',fontFamily:'var(--font-body)',fontWeight:400,fontSize:'14px',color:disabled?'var(--text-muted)':'var(--text-body)',...style}}>
    <span role="switch" aria-checked={checked} onClick={()=>!disabled&&onChange&&onChange(!checked)}
      style={{width:'38px',height:'22px',borderRadius:'var(--radius-pill)',flexShrink:0,position:'relative',
        background:disabled?'var(--border-subtle)':checked?'var(--action-primary)':'var(--neutral-600)',transition:'background var(--transition-base)'}}>
      <span style={{position:'absolute',top:'3px',left:checked?'19px':'3px',width:'16px',height:'16px',borderRadius:'50%',background:'#fff',transition:'left var(--transition-base)'}}></span>
    </span>{label}</label>;
}
