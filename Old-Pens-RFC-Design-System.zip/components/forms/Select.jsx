import React,{useState} from 'react';
export function Select({label,options=[],disabled=false,style,...rest}){
  const [focus,setFocus]=useState(false);
  return <label style={{display:'block',fontFamily:'var(--font-body)'}}>
    {label&&<span style={{display:'block',fontFamily:'var(--font-headline)',fontWeight:600,fontSize:'12px',textTransform:'uppercase',letterSpacing:'var(--tracking-caps)',color:'var(--text-heading)',marginBottom:'6px'}}>{label}</span>}
    <span style={{position:'relative',display:'block'}}>
      <select disabled={disabled} onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
        style={{display:'block',width:'100%',appearance:'none',WebkitAppearance:'none',padding:'10px 32px 10px 12px',fontFamily:'var(--font-body)',fontWeight:400,fontSize:'14px',
          color:'var(--text-body)',background:disabled?'var(--neutral-100)':'var(--surface-card)',
          border:`1px solid ${focus?'var(--action-primary)':'var(--border-subtle)'}`,borderRadius:'var(--radius-sm)',outline:'none',
          boxShadow:focus?'var(--shadow-focus)':'none',cursor:disabled?'not-allowed':'pointer',...style}} {...rest}>
        {options.map(o=>typeof o==='string'?<option key={o} value={o}>{o}</option>:<option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      <span aria-hidden="true" style={{position:'absolute',right:'12px',top:'50%',transform:'translateY(-50%)',pointerEvents:'none',color:'var(--text-muted)',fontSize:'10px'}}>▾</span>
    </span>
  </label>;
}
