import React,{useState} from 'react';
export function Button({variant='primary',size='md',disabled=false,fullWidth=false,children,style,...rest}){
  const [hover,setHover]=useState(false);const [press,setPress]=useState(false);
  const sizes={sm:{padding:'7px 14px',fontSize:'12px'},md:{padding:'10px 22px',fontSize:'13px'},lg:{padding:'14px 30px',fontSize:'15px'}};
  const v={
    primary:{bg:'var(--action-primary)',bgH:'var(--action-primary-hover)',bgA:'var(--action-primary-active)',fg:'#fff',bd:'transparent'},
    gold:{bg:'var(--accent)',bgH:'var(--accent-strong)',bgA:'var(--accent-strong)',fg:'var(--text-on-gold)',bd:'transparent'},
    secondary:{bg:hover?'rgba(36,89,157,.08)':'transparent',bgH:'rgba(36,89,157,.08)',bgA:'rgba(36,89,157,.15)',fg:'var(--action-primary)',bd:'var(--action-primary)'},
    ghost:{bg:'transparent',bgH:'rgba(36,89,157,.08)',bgA:'rgba(36,89,157,.15)',fg:'var(--action-primary)',bd:'transparent'},
    danger:{bg:'var(--danger)',bgH:'var(--danger-strong)',bgA:'var(--danger-strong)',fg:'#fff',bd:'transparent'}
  }[variant];
  const bg=disabled?'var(--border-subtle)':press?v.bgA:hover?v.bgH:v.bg;
  return <button disabled={disabled}
    onMouseEnter={()=>setHover(true)} onMouseLeave={()=>{setHover(false);setPress(false);}}
    onMouseDown={()=>setPress(true)} onMouseUp={()=>setPress(false)}
    style={{fontFamily:'var(--font-headline)',fontWeight:700,textTransform:'uppercase',letterSpacing:'var(--tracking-caps)',
      border:`1px solid ${disabled?'transparent':v.bd}`,borderRadius:'var(--radius-sm)',cursor:disabled?'not-allowed':'pointer',
      color:disabled?'var(--text-muted)':v.fg,background:bg,transition:'background var(--transition-fast)',
      width:fullWidth?'100%':undefined,...sizes[size],...style}} {...rest}>{children}</button>;
}
