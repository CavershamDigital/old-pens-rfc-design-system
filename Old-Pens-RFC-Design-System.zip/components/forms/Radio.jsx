import React from 'react';
export function Radio({label,name,value,checked=false,disabled=false,onChange,style}){
  return <label style={{display:'inline-flex',alignItems:'center',gap:'10px',cursor:disabled?'not-allowed':'pointer',fontFamily:'var(--font-body)',fontWeight:400,fontSize:'14px',color:disabled?'var(--text-muted)':'var(--text-body)',...style}}>
    <span style={{position:'relative',width:'18px',height:'18px',flexShrink:0}}>
      <input type="radio" name={name} value={value} checked={checked} disabled={disabled} onChange={()=>onChange&&onChange(value)}
        style={{position:'absolute',inset:0,opacity:0,margin:0,cursor:'inherit'}}/>
      <span aria-hidden="true" style={{position:'absolute',inset:0,borderRadius:'50%',
        border:`1px solid ${checked?'var(--action-primary)':'var(--neutral-600)'}`,
        background:disabled?'var(--neutral-100)':'var(--surface-card)',display:'flex',alignItems:'center',justifyContent:'center'}}>
        {checked&&<span style={{width:'10px',height:'10px',borderRadius:'50%',background:'var(--action-primary)'}}></span>}
      </span>
    </span>{label}</label>;
}
