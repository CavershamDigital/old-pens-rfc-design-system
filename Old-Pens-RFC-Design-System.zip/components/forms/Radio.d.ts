/** Radio option; group by shared name, controlled via checked/onChange(value). */
export interface RadioProps {
  label?: React.ReactNode;
  name?: string;
  value?: string;
  checked?: boolean;
  disabled?: boolean;
  onChange?: (value: string) => void;
}
export declare function Radio(props: RadioProps): JSX.Element;
