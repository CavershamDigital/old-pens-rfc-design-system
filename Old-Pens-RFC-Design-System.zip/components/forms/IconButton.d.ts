/** Square icon-only button; requires an accessible label. */
export interface IconButtonProps {
  /** Accessible name (aria-label + tooltip) */
  label: string;
  variant?: 'primary' | 'gold' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  /** The icon glyph/SVG */
  children?: React.ReactNode;
  onClick?: () => void;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
