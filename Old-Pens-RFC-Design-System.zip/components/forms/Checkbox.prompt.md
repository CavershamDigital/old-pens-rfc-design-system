Checkbox — controlled checkbox with label.

```jsx
<Checkbox label="I agree to the code of conduct" checked={v} onChange={setV} />
```
