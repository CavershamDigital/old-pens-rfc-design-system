Radio — single option in a group; share `name`, control with checked/onChange.

```jsx
<Radio name="team" value="seniors" label="Seniors" checked={t==='seniors'} onChange={setT} />
```
