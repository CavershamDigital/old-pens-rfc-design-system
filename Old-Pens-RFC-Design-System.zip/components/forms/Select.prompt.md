Select — styled native dropdown.

```jsx
<Select label="Age group" options={['Under 8s','Under 10s','Seniors']} />
```
