IconButton — square icon-only button (28/36/44px); always pass `label` for accessibility. Use Lucide icons (see readme ICONOGRAPHY).

```jsx
<IconButton label="Close" variant="ghost"><svg …/></IconButton>
```
