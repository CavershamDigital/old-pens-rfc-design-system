import React,{useState} from 'react';
export function Input({label,hint,error,type='text',disabled=false,style,...rest}){
  const [focus,setFocus]=useState(false);
  return <label style={{display:'block',fontFamily:'var(--font-body)'}}>
    {label&&<span style={{display:'block',fontFamily:'var(--font-headline)',fontWeight:600,fontSize:'12px',textTransform:'uppercase',letterSpacing:'var(--tracking-caps)',color:'var(--text-heading)',marginBottom:'6px'}}>{label}</span>}
    <input type={type} disabled={disabled} onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
      style={{display:'block',width:'100%',boxSizing:'border-box',padding:'10px 12px',fontFamily:'var(--font-body)',fontWeight:400,fontSize:'14px',
        color:'var(--text-body)',background:disabled?'var(--neutral-100)':'var(--surface-card)',
        border:`1px solid ${error?'var(--danger)':focus?'var(--action-primary)':'var(--border-subtle)'}`,
        borderRadius:'var(--radius-sm)',outline:'none',boxShadow:focus?'var(--shadow-focus)':'none',transition:'box-shadow var(--transition-fast)',...style}} {...rest}/>
    {error?<span style={{display:'block',fontSize:'12px',fontWeight:400,color:'var(--danger-strong)',marginTop:'4px'}}>{error}</span>
      :hint?<span style={{display:'block',fontSize:'12px',fontWeight:400,color:'var(--text-muted)',marginTop:'4px'}}>{hint}</span>:null}
  </label>;
}
