import React,{useState} from 'react';
export function IconButton({label,variant='ghost',size='md',disabled=false,children,style,...rest}){
  const [hover,setHover]=useState(false);
  const dim={sm:28,md:36,lg:44}[size];
  const v={
    primary:{bg:'var(--action-primary)',bgH:'var(--action-primary-hover)',fg:'#fff'},
    gold:{bg:'var(--accent)',bgH:'var(--accent-strong)',fg:'var(--text-on-gold)'},
    ghost:{bg:hover?'rgba(36,89,157,.10)':'transparent',bgH:'rgba(36,89,157,.10)',fg:'var(--action-primary)'}
  }[variant];
  return <button aria-label={label} title={label} disabled={disabled}
    onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
    style={{width:dim,height:dim,display:'inline-flex',alignItems:'center',justifyContent:'center',
      border:'none',borderRadius:'var(--radius-sm)',cursor:disabled?'not-allowed':'pointer',
      background:disabled?'var(--border-subtle)':hover?v.bgH:v.bg,color:disabled?'var(--text-muted)':v.fg,
      fontSize:dim*0.5,transition:'background var(--transition-fast)',...style}} {...rest}>{children}</button>;
}
