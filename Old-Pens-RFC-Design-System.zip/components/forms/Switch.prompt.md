Switch — on/off toggle for settings.

```jsx
<Switch label="Email me fixture updates" checked={v} onChange={setV} />
```
