/** Single-line text field with label, hint and error states. */
export interface InputProps {
  label?: string;
  hint?: string;
  /** Error message; presence switches the field to error styling */
  error?: string;
  type?: string;
  placeholder?: string;
  value?: string;
  disabled?: boolean;
  onChange?: (e: any) => void;
}
export declare function Input(props: InputProps): JSX.Element;
