/**
 * Primary action button in the Old Pens house style — Montserrat Bold uppercase.
 * @startingPoint section="Components" subtitle="Buttons in all five variants" viewport="700x260"
 */
export interface ButtonProps {
  /** Visual style */
  variant?: 'primary' | 'gold' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  fullWidth?: boolean;
  children?: React.ReactNode;
  onClick?: () => void;
}
export declare function Button(props: ButtonProps): JSX.Element;
