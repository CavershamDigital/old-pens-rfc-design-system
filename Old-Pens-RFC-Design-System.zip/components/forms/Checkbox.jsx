import React from 'react';
export function Checkbox({label,checked=false,disabled=false,onChange,style}){
  return <label style={{display:'inline-flex',alignItems:'center',gap:'10px',cursor:disabled?'not-allowed':'pointer',fontFamily:'var(--font-body)',fontWeight:400,fontSize:'14px',color:disabled?'var(--text-muted)':'var(--text-body)',...style}}>
    <span style={{position:'relative',width:'18px',height:'18px',flexShrink:0}}>
      <input type="checkbox" checked={checked} disabled={disabled} onChange={e=>onChange&&onChange(e.target.checked)}
        style={{position:'absolute',inset:0,opacity:0,margin:0,cursor:'inherit'}}/>
      <span aria-hidden="true" style={{position:'absolute',inset:0,borderRadius:'var(--radius-sm)',
        border:`1px solid ${checked?'var(--action-primary)':'var(--neutral-600)'}`,
        background:disabled?'var(--neutral-100)':checked?'var(--action-primary)':'var(--surface-card)',
        display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:'12px',fontWeight:700,transition:'background var(--transition-fast)'}}>{checked?'✓':''}</span>
    </span>{label}</label>;
}
