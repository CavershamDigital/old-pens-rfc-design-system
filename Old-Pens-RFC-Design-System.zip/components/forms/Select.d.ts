/** Native select dressed in the house style. */
export interface SelectProps {
  label?: string;
  /** Strings or {value,label} pairs */
  options?: Array<string | { value: string; label: string }>;
  value?: string;
  disabled?: boolean;
  onChange?: (e: any) => void;
}
export declare function Select(props: SelectProps): JSX.Element;
