Card — white content card with soft navy shadow; optional `kicker` (gold eyebrow), `accent` top border, cover `image`, `footer`.

```jsx
<Card kicker="Club news" title="Minis return Saturday" footer="2 Sep 2026">Body copy…</Card>
```
