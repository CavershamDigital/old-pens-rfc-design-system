Badge — solid uppercase label for status (HOME, AWAY, FULL TIME, NEW).

```jsx
<Badge tone="gold">Home</Badge> <Badge tone="red">Live</Badge>
```
