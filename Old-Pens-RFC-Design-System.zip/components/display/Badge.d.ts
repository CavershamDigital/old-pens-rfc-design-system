/** Solid uppercase status badge. */
export interface BadgeProps {
  tone?: 'navy' | 'blue' | 'gold' | 'red' | 'neutral';
  children?: React.ReactNode;
}
export declare function Badge(props: BadgeProps): JSX.Element;
