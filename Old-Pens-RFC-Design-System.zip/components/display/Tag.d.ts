/** Quiet pill tag, optionally removable. */
export interface TagProps {
  children?: React.ReactNode;
  /** Renders a ✕ remove affordance */
  onRemove?: () => void;
}
export declare function Tag(props: TagProps): JSX.Element;
