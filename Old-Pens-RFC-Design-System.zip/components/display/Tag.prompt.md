Tag — quiet outlined pill for metadata (age groups, categories); `onRemove` makes it dismissible.

```jsx
<Tag>Under 10s</Tag> <Tag onRemove={fn}>Away fixtures</Tag>
```
