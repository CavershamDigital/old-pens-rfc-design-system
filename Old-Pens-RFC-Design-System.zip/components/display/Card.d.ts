/** Content card: white surface, soft navy shadow, optional gold top accent and cover image. */
export interface CardProps {
  title?: string;
  /** Small gold uppercase eyebrow above the title */
  kicker?: string;
  footer?: React.ReactNode;
  /** Gold top border accent */
  accent?: boolean;
  /** Cover image URL */
  image?: string;
  children?: React.ReactNode;
}
export declare function Card(props: CardProps): JSX.Element;
