import React from 'react';
export function Card({title,kicker,footer,accent=false,image,children,style}){
  return <div style={{background:'var(--surface-card)',borderRadius:'var(--radius-md)',boxShadow:'var(--shadow-card)',overflow:'hidden',borderTop:accent?'var(--border-width-heavy) solid var(--accent)':'none',fontFamily:'var(--font-body)',...style}}>
    {image&&<img src={image} alt="" style={{display:'block',width:'100%',height:'160px',objectFit:'cover'}}/>}
    <div style={{padding:'var(--space-5)'}}>
      {kicker&&<div style={{fontFamily:'var(--font-headline)',fontWeight:600,fontSize:'11px',textTransform:'uppercase',letterSpacing:'var(--tracking-caps)',color:'var(--accent)',marginBottom:'6px'}}>{kicker}</div>}
      {title&&<h3 style={{fontSize:'var(--text-lg)',marginBottom:'8px'}}>{title}</h3>}
      <div style={{fontWeight:400,fontSize:'14px',color:'var(--text-body)',lineHeight:'var(--leading-body)'}}>{children}</div>
    </div>
    {footer&&<div style={{padding:'12px var(--space-5)',borderTop:'1px solid var(--border-subtle)',fontSize:'13px',fontWeight:400,color:'var(--text-muted)'}}>{footer}</div>}
  </div>;
}
