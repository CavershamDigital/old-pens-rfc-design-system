import React from 'react';
export function Badge({tone='navy',children,style}){
  const t={
    navy:{bg:'var(--surface-inverse)',fg:'var(--text-inverse)'},
    blue:{bg:'var(--action-primary)',fg:'#fff'},
    gold:{bg:'var(--accent)',fg:'var(--text-on-gold)'},
    red:{bg:'var(--danger)',fg:'#fff'},
    neutral:{bg:'var(--neutral-100)',fg:'var(--text-muted)'}
  }[tone];
  return <span style={{display:'inline-block',padding:'3px 10px',borderRadius:'var(--radius-sm)',background:t.bg,color:t.fg,
    fontFamily:'var(--font-headline)',fontWeight:700,fontSize:'11px',textTransform:'uppercase',letterSpacing:'var(--tracking-caps)',...style}}>{children}</span>;
}
