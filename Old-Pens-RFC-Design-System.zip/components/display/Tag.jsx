import React from 'react';
export function Tag({children,onRemove,style}){
  return <span style={{display:'inline-flex',alignItems:'center',gap:'6px',padding:'4px 10px',borderRadius:'var(--radius-pill)',
    border:'1px solid var(--border-subtle)',background:'var(--surface-card)',color:'var(--text-body)',
    fontFamily:'var(--font-body)',fontWeight:400,fontSize:'13px',...style}}>{children}
    {onRemove&&<button onClick={onRemove} aria-label="Remove" style={{border:'none',background:'none',cursor:'pointer',color:'var(--text-muted)',fontSize:'12px',padding:0,lineHeight:1}}>✕</button>}
  </span>;
}
