Tabs — uppercase tab strip with gold underline on the active tab.

```jsx
<Tabs tabs={['Fixtures','Results','Tables']} active={tab} onChange={setTab} />
```
