import React from 'react';
export function Tabs({tabs=[],active,onChange,style}){
  return <div role="tablist" style={{display:'flex',gap:'4px',borderBottom:'2px solid var(--border-subtle)',fontFamily:'var(--font-headline)',...style}}>
    {tabs.map(t=>{const sel=t===active;
      return <button key={t} role="tab" aria-selected={sel} onClick={()=>onChange&&onChange(t)}
        style={{padding:'10px 18px',border:'none',background:'none',cursor:'pointer',fontFamily:'inherit',fontWeight:sel?700:500,fontSize:'13px',
          textTransform:'uppercase',letterSpacing:'var(--tracking-caps)',color:sel?'var(--text-heading)':'var(--text-muted)',
          boxShadow:sel?'inset 0 -3px 0 var(--accent)':'none',marginBottom:'-2px',transition:'color var(--transition-fast)'}}>{t}</button>;})}
  </div>;
}
