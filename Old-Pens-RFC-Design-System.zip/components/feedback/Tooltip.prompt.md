Tooltip — small dark label on hover/focus.

```jsx
<Tooltip label="Download fixtures"><IconButton label="Download">↓</IconButton></Tooltip>
```
