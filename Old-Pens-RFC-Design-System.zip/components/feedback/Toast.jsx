import React from 'react';
export function Toast({tone='info',title,onClose,children,style}){
  const t={
    info:{bar:'var(--action-primary)'},
    success:{bar:'var(--accent)'},
    error:{bar:'var(--danger)'}
  }[tone];
  return <div role="status" style={{display:'flex',alignItems:'flex-start',gap:'12px',maxWidth:'380px',background:'var(--surface-inverse)',color:'var(--text-inverse)',
    borderRadius:'var(--radius-md)',boxShadow:'var(--shadow-raised)',padding:'14px 16px',fontFamily:'var(--font-body)',position:'relative',overflow:'hidden',...style}}>
    <span aria-hidden="true" style={{position:'absolute',left:0,top:0,bottom:0,width:'4px',background:t.bar}}></span>
    <div style={{flex:1,paddingLeft:'6px'}}>
      {title&&<div style={{fontFamily:'var(--font-headline)',fontWeight:700,fontSize:'13px',textTransform:'uppercase',letterSpacing:'var(--tracking-caps)',marginBottom:'2px'}}>{title}</div>}
      <div style={{fontWeight:300,fontSize:'13px',lineHeight:'var(--leading-snug)'}}>{children}</div>
    </div>
    {onClose&&<button onClick={onClose} aria-label="Dismiss" style={{border:'none',background:'none',color:'var(--text-inverse)',cursor:'pointer',fontSize:'13px',padding:0,opacity:.7}}>✕</button>}
  </div>;
}
