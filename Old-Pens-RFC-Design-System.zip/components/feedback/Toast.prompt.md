Toast — navy notification; tone edge bar in blue/gold/red.

```jsx
<Toast tone="success" title="Saved" onClose={fn}>Kick-off updated to 14:30.</Toast>
```
