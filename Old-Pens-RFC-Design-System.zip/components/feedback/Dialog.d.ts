/** Modal dialog with navy header bar; overlay click or ✕ closes. */
export interface DialogProps {
  open?: boolean;
  title?: string;
  onClose?: () => void;
  /** Footer action buttons; defaults to a single OK */
  actions?: React.ReactNode;
  children?: React.ReactNode;
}
export declare function Dialog(props: DialogProps): JSX.Element;
