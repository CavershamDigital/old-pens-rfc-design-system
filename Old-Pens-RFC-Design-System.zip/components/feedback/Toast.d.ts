/** Navy toast notification with tone edge bar. */
export interface ToastProps {
  tone?: 'info' | 'success' | 'error';
  title?: string;
  onClose?: () => void;
  children?: React.ReactNode;
}
export declare function Toast(props: ToastProps): JSX.Element;
