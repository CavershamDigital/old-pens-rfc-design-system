import React,{useState} from 'react';
export function Tooltip({label,children,style}){
  const [show,setShow]=useState(false);
  return <span style={{position:'relative',display:'inline-block',...style}}
    onMouseEnter={()=>setShow(true)} onMouseLeave={()=>setShow(false)} onFocus={()=>setShow(true)} onBlur={()=>setShow(false)}>
    {children}
    {show&&<span role="tooltip" style={{position:'absolute',bottom:'calc(100% + 8px)',left:'50%',transform:'translateX(-50%)',whiteSpace:'nowrap',
      background:'var(--neutral-900)',color:'#fff',fontFamily:'var(--font-body)',fontWeight:400,fontSize:'12px',padding:'6px 10px',
      borderRadius:'var(--radius-sm)',boxShadow:'var(--shadow-card)',zIndex:100}}>{label}</span>}
  </span>;
}
