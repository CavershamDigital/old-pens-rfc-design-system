Dialog — modal with navy header bar and navy scrim.

```jsx
<Dialog open={open} title="Confirm selection" onClose={close}
  actions={<><Button variant="ghost" onClick={close}>Cancel</Button><Button onClick={ok}>Confirm</Button></>}>
  Are you sure?
</Dialog>
```
