import React from 'react';
import {Button} from '../forms/Button.jsx';
export function Dialog({open=false,title,onClose,actions,children,style}){
  if(!open)return null;
  return <div onClick={onClose} style={{position:'fixed',inset:0,background:'rgba(20,39,76,.55)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,padding:'24px'}}>
    <div role="dialog" aria-modal="true" onClick={e=>e.stopPropagation()}
      style={{background:'var(--surface-card)',borderRadius:'var(--radius-md)',boxShadow:'var(--shadow-raised)',maxWidth:'440px',width:'100%',overflow:'hidden',fontFamily:'var(--font-body)',...style}}>
      <div style={{padding:'18px 24px',background:'var(--surface-inverse)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <h3 style={{color:'var(--text-inverse)',fontSize:'16px',textTransform:'uppercase',letterSpacing:'var(--tracking-caps)'}}>{title}</h3>
        <button onClick={onClose} aria-label="Close" style={{border:'none',background:'none',color:'var(--text-inverse)',cursor:'pointer',fontSize:'16px',padding:0}}>✕</button>
      </div>
      <div style={{padding:'24px',fontWeight:400,fontSize:'14px',lineHeight:'var(--leading-body)'}}>{children}</div>
      <div style={{padding:'16px 24px',borderTop:'1px solid var(--border-subtle)',display:'flex',justifyContent:'flex-end',gap:'10px'}}>
        {actions||<Button variant="primary" onClick={onClose}>OK</Button>}
      </div>
    </div>
  </div>;
}
