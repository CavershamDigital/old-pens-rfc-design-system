/** Hover/focus tooltip above the wrapped element. */
export interface TooltipProps {
  label: string;
  children?: React.ReactNode;
}
export declare function Tooltip(props: TooltipProps): JSX.Element;
