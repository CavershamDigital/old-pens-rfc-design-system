function Header({screen,onNav}){
  const links=['Home','Fixtures','Join'];
  return <header style={{background:'var(--surface-inverse)',color:'var(--text-inverse)'}}>
    <div style={{maxWidth:1120,margin:'0 auto',padding:'0 24px',display:'flex',alignItems:'center',gap:20,height:72}}>
      <img src="../../assets/OPRFC-Final-Crest-Only.png" alt="OPRFC crest" style={{width:48,height:48}}/>
      <div style={{fontFamily:'var(--font-clubname)',fontSize:24,lineHeight:1}}>Old Penarthians R.F.C</div>
      <nav style={{marginLeft:'auto',display:'flex',gap:8}}>
        {links.map(l=><a key={l} href="#" onClick={e=>{e.preventDefault();onNav(l);}}
          style={{fontFamily:'var(--font-headline)',fontWeight:600,fontSize:12,textTransform:'uppercase',letterSpacing:'var(--tracking-caps)',
            color:screen===l?'var(--accent-bright)':'var(--text-inverse)',textDecoration:'none',padding:'10px 14px',
            boxShadow:screen===l?'inset 0 -3px 0 var(--accent)':'none'}}>{l}</a>)}
      </nav>
    </div>
  </header>;
}
function Footer(){
  return <footer style={{background:'var(--surface-inverse)',color:'var(--text-inverse)',marginTop:64}}>
    <div style={{maxWidth:1120,margin:'0 auto',padding:'28px 24px',display:'flex',alignItems:'center',gap:16}}>
      <img src="../../assets/OPRFC-Final-Crest-Only.png" alt="" style={{width:36,height:36}}/>
      <div style={{fontSize:12,fontWeight:300,opacity:.85}}>Old Penarthians RFC · Cwrt-y-Vil Playing Fields, St. Marks Road, Penarth, CF64 3PF</div>
    </div>
  </footer>;
}
Object.assign(window,{Header,Footer});
