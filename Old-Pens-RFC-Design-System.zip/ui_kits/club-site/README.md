# Club Site UI kit

Old Penarthians RFC club-website screens: Home (hero + next fixture + news), Fixtures & Results, and Join the Club (membership form).

**Note:** no existing product UI (codebase/Figma) was provided — these screens are an original composition built strictly from the 2025 brand guidelines and the design-system components, not a recreation of the club's live website (oldpenarthians.rfc.wales). Replace with recreations if a source becomes available.

Files: `index.html` (interactive shell), `Header.jsx`, `HomeScreen.jsx`, `FixturesScreen.jsx`, `JoinScreen.jsx`.
