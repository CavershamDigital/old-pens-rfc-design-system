function FixturesScreen(){
  const {Tabs,Badge,Card}=window.OldPensRFCDesignSystem_560a26;
  const [tab,setTab]=React.useState('Fixtures');
  const fixtures=[
    {date:'Sat 12 Sep',opp:"St Peter's",ha:'Home',ko:'14:30'},
    {date:'Sat 19 Sep',opp:'Dinas Powys',ha:'Away',ko:'14:30'},
    {date:'Sat 26 Sep',opp:'Wenvoe',ha:'Home',ko:'14:30'},
    {date:'Sat 3 Oct',opp:'Cowbridge',ha:'Away',ko:'14:00'}];
  const results=[
    {date:'Sat 25 Apr',opp:'Llandaff North',ha:'Home',f:24,a:17},
    {date:'Sat 18 Apr',opp:'Fairwater',ha:'Away',f:12,a:31},
    {date:'Sat 11 Apr',opp:'Cardiff Quins',ha:'Home',f:38,a:10}];
  const rowStyle={display:'flex',alignItems:'center',gap:16,padding:'16px 20px',borderBottom:'1px solid var(--border-subtle)'};
  return <div style={{maxWidth:900,margin:'0 auto',padding:'40px 24px 0'}}>
    <h1 style={{fontSize:'var(--text-2xl)',textTransform:'uppercase',marginBottom:24}}>Fixtures &amp; results</h1>
    <Tabs tabs={['Fixtures','Results']} active={tab} onChange={setTab}/>
    <div style={{background:'var(--surface-card)',borderRadius:'0 0 var(--radius-md) var(--radius-md)',boxShadow:'var(--shadow-card)'}}>
      {tab==='Fixtures'?fixtures.map(f=><div key={f.date} style={rowStyle}>
        <span style={{width:96,fontWeight:300,fontSize:13,color:'var(--text-muted)'}}>{f.date}</span>
        <Badge tone={f.ha==='Home'?'gold':'navy'}>{f.ha}</Badge>
        <span style={{fontFamily:'var(--font-headline)',fontWeight:700,fontSize:15,textTransform:'uppercase'}}>Old Penarthians vs {f.opp}</span>
        <span style={{marginLeft:'auto',fontWeight:300,fontSize:13,color:'var(--text-muted)'}}>KO <span style={{fontFamily:'var(--font-number)',fontSize:19,color:'var(--text-heading)'}}>{f.ko}</span></span>
      </div>)
      :results.map(r=><div key={r.date} style={rowStyle}>
        <span style={{width:96,fontWeight:300,fontSize:13,color:'var(--text-muted)'}}>{r.date}</span>
        <Badge tone={r.ha==='Home'?'gold':'navy'}>{r.ha}</Badge>
        <span style={{fontFamily:'var(--font-headline)',fontWeight:700,fontSize:15,textTransform:'uppercase'}}>Old Penarthians vs {r.opp}</span>
        <span style={{marginLeft:'auto',display:'flex',alignItems:'center',gap:10}}>
          <span style={{fontFamily:'var(--font-number)',fontSize:26,color:r.f>r.a?'var(--action-primary)':'var(--danger-strong)'}}>{r.f} – {r.a}</span>
          <Badge tone={r.f>r.a?'blue':'red'}>{r.f>r.a?'Won':'Lost'}</Badge>
        </span>
      </div>)}
    </div>
  </div>;
}
Object.assign(window,{FixturesScreen});
