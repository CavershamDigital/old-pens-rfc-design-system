function JoinScreen(){
  const {Input,Select,Checkbox,Radio,Switch,Button,Dialog,Toast}=window.OldPensRFCDesignSystem_560a26;
  const [section,setSection]=React.useState('seniors');
  const [conduct,setConduct]=React.useState(false);
  const [news,setNews]=React.useState(true);
  const [open,setOpen]=React.useState(false);
  const [sent,setSent]=React.useState(false);
  return <div style={{maxWidth:640,margin:'0 auto',padding:'40px 24px 0'}}>
    <h1 style={{fontSize:'var(--text-2xl)',textTransform:'uppercase'}}>Join the club</h1>
    <p style={{fontWeight:300,fontSize:14,color:'var(--text-muted)',margin:'10px 0 28px'}}>Minis, juniors, seniors and social members — everyone is welcome down the Pens.</p>
    <div style={{background:'var(--surface-card)',borderRadius:'var(--radius-md)',boxShadow:'var(--shadow-card)',padding:32,display:'flex',flexDirection:'column',gap:18}}>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
        <Input label="First name" placeholder="Dai"/>
        <Input label="Surname" placeholder="Evans"/>
      </div>
      <Input label="Email" type="email" placeholder="you@example.com" hint="Used for club communications only."/>
      <Select label="Age group" options={['Seniors','Youth','Under 12s','Under 10s','Under 8s','Minis']}/>
      <div style={{display:'flex',gap:20,flexWrap:'wrap'}}>
        <Radio name="sec" value="seniors" label="Playing member" checked={section==='seniors'} onChange={setSection}/>
        <Radio name="sec" value="social" label="Social member" checked={section==='social'} onChange={setSection}/>
        <Radio name="sec" value="volunteer" label="Volunteer" checked={section==='volunteer'} onChange={setSection}/>
      </div>
      <Checkbox label="I agree to the club code of conduct" checked={conduct} onChange={setConduct}/>
      <Switch label="Email me fixture updates" checked={news} onChange={setNews}/>
      <div><Button variant="gold" size="lg" disabled={!conduct} onClick={()=>setOpen(true)}>Submit application</Button></div>
    </div>
    {sent&&<div style={{position:'fixed',bottom:24,right:24,zIndex:50}}><Toast tone="success" title="Application sent" onClose={()=>setSent(false)}>We'll be in touch before the weekend.</Toast></div>}
    <Dialog open={open} title="Confirm application" onClose={()=>setOpen(false)}
      actions={<React.Fragment><Button variant="ghost" onClick={()=>setOpen(false)}>Cancel</Button><Button onClick={()=>{setOpen(false);setSent(true);}}>Confirm</Button></React.Fragment>}>
      Send your membership application to the club secretary?
    </Dialog>
  </div>;
}
Object.assign(window,{JoinScreen});
