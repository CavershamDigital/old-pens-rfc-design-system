function HomeScreen({onNav}){
  const {Button,Card,Badge}=window.OldPensRFCDesignSystem_560a26;
  return <div>
    <section style={{position:'relative',height:420,overflow:'hidden'}}>
      <img src="../../assets/old-penarthians-team.jpg" alt="Old Pens in action" style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'cover'}}/>
      <div style={{position:'absolute',inset:0,background:'linear-gradient(90deg, rgba(20,39,76,.88) 0%, rgba(20,39,76,.55) 45%, rgba(20,39,76,.15) 100%)'}}></div>
      <div style={{position:'relative',maxWidth:1120,margin:'0 auto',padding:'0 24px',height:'100%',display:'flex',flexDirection:'column',justifyContent:'center',gap:18}}>
        <div style={{fontFamily:'var(--font-headline)',fontWeight:600,fontSize:13,textTransform:'uppercase',letterSpacing:'var(--tracking-caps)',color:'var(--accent-bright)'}}>Est. Penarth · Rugby for everyone</div>
        <h1 style={{color:'#fff',fontSize:'var(--text-3xl)',textTransform:'uppercase',maxWidth:'14ch'}}>Mon the Pens</h1>
        <p style={{color:'var(--text-inverse)',fontWeight:300,fontSize:16,maxWidth:'44ch',margin:0}}>Community rugby at Cwrt-y-Vil — minis on Sunday mornings, seniors on Saturday afternoons.</p>
        <div style={{display:'flex',gap:12}}>
          <Button variant="gold" size="lg" onClick={()=>onNav('Join')}>Join the club</Button>
          <Button variant="secondary" size="lg" style={{color:'#fff',borderColor:'#fff'}} onClick={()=>onNav('Fixtures')}>Fixtures</Button>
        </div>
      </div>
    </section>
    <section style={{background:'var(--surface-raised)'}}>
      <div style={{maxWidth:1120,margin:'0 auto',padding:'20px 24px',display:'flex',alignItems:'center',gap:24,color:'var(--text-inverse)',flexWrap:'wrap'}}>
        <Badge tone="gold">Next fixture</Badge>
        <div style={{display:'flex',alignItems:'baseline',gap:14}}>
          <span style={{fontFamily:'var(--font-headline)',fontWeight:700,fontSize:18,textTransform:'uppercase'}}>Old Penarthians</span>
          <span style={{fontFamily:'var(--font-number)',fontSize:30,color:'var(--accent-bright)'}}>VS</span>
          <span style={{fontFamily:'var(--font-headline)',fontWeight:700,fontSize:18,textTransform:'uppercase'}}>St Peter's</span>
        </div>
        <div style={{marginLeft:'auto',fontWeight:300,fontSize:14}}>Sat 12 Sep · KO <span style={{fontFamily:'var(--font-number)',fontSize:20}}>14:30</span> · Cwrt-y-Vil</div>
      </div>
    </section>
    <section style={{maxWidth:1120,margin:'0 auto',padding:'48px 24px 0'}}>
      <h2 style={{fontSize:'var(--text-xl)',textTransform:'uppercase',marginBottom:24}}>Club news</h2>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:24}}>
        <Card image="../../assets/old-penarthians-team.jpg" kicker="Seniors" title="Pre-season friendly confirmed" footer="2 Sep 2026">The 1st XV host St Peter's in the final warm-up before the league opener.</Card>
        <Card accent kicker="Minis & juniors" title="Registration Sunday" footer="30 Aug 2026">New season sign-on at the clubhouse from 9:30am — new players always welcome.</Card>
        <Card kicker="Clubhouse" title="Kit shop open" footer="28 Aug 2026">This season's playing and training range is now available to order.</Card>
      </div>
    </section>
  </div>;
}
Object.assign(window,{HomeScreen});
