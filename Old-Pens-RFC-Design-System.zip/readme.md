# Old Penarthians RFC Design System

Design system for **Old Penarthians Rugby Football Club** ("Old Pens" / OPRFC), a community rugby club at Cwrt-y-Vil Playing Fields, St. Marks Road, Penarth, CF64 3PF (Wales). The club runs minis, juniors and senior sides. This system is built from the club's **2025 Brand Guidelines**.

**Sources provided**
- Local folder `Brand Guidelines/` (mounted): `OLD_PENS_BRAND_GUIDELINES_2025/` containing the 8-page guidelines PDF (`Old Pens Brand Guidelines 2025.pdf`, copied to `source/`), fonts (Montserrat variable, Bebas Neue, Old English), crest PNG, match photography, and kit-mockup PDFs. An `OLD-DO-NOT-USE/` folder holds superseded logos/fonts (Exo 2, Autobus) — deliberately ignored.
- No product codebase, Figma file, or website source was provided. Components are a standard set styled to the guidelines; the UI kit is an original composition (see caveats in `ui_kits/club-site/README.md`).

## CONTENT FUNDAMENTALS

The guidelines contain no copy/tone guide, so these are inferred from the brand's character and typical club communications:
- Voice: warm, direct, community-first. Second person ("you"), club as "we". E.g. "Everyone is welcome down the Pens", "New players always welcome".
- Casing: headlines set in UPPERCASE Montserrat Bold ("bold and brave"); body copy sentence case, Montserrat Light, ~14px ("light, simple and clean").
- The full club name "Old Penarthians R.F.C" is a display element — set it in Old English **only** where the club name itself is displayed; use "Old Pens" or "OPRFC" in running copy.
- Numbers with sporting meaning (scores, kick-off times, shirt numbers) may be set in Bebas Neue for punch; Bebas is otherwise reserved for the back of shirts.
- No emoji. Welsh place names appear naturally (Cwrt-y-Vil, Penarth).
- Related but separate: the club's document house style (Word/PDF paperwork) uses navy `#1B2B4B` / gold `#C49A2A` / Arial — that predates the 2025 guidelines and applies to club paperwork, not this system.

## VISUAL FOUNDATIONS

- **Colors** — Primary: three golds (#EC9522 lead, #EBAE20, #FDDA31 bright) and three blues (#24599D club blue, #203A71, #14274C deep navy). Secondary: neutrals (#F3F3F3, #515151, #090B0C) and crest reds (#FF0025, #E02027, #B7000E). Golds are accents and standout CTAs; blues carry surfaces and primary actions; reds are for danger/"live" only. Text on gold is always navy.
- **Type** — Montserrat Bold (700) for headlines/titles, often uppercase with 0.08em tracking on labels; Montserrat Light (300) body at 14px, 500 for emphasis. Old English = club name only. Bebas Neue = shirt/score numbers only. Scale: 12/14/16/20/28/40/56.
- **Spacing** — 4px base scale (4–64). Layout max-width ~1120px.
- **Backgrounds** — flat light grey page (#F3F3F3), white cards, deep navy inverse sections; full-bleed match photography with navy protection gradients over the text side. No patterns, textures, or decorative gradients.
- **Imagery** — real match photography: action shots, grass, mud; warm natural colour. Never illustration.
- **Corners** — small: 4px controls, 8px cards, 12px large; pill only for tags/switch.
- **Borders** — 1px subtle #E3E3E3; 3px gold top-accent on highlighted cards; heavy use of solid colour blocks over borders.
- **Shadows** — navy-tinted, soft: `--shadow-card` (cards), `--shadow-raised` (modals/toasts), gold `--shadow-focus` ring on focused inputs.
- **Animation** — minimal: 120–200ms ease on background/color/position; no bounces or entrance animations.
- **Hover** — darker fill on solid buttons; 8% blue tint on ghost/outline; links darken + underline. **Press** — darkest step of the ramp. No scale transforms.
- **Logo rules** — 50px minimum clear space around the crest; never display below 50px wide.

## ICONOGRAPHY

- The brand guidelines define **no icon system**; no icon assets were provided beyond the crest.
- The crest (`assets/OPRFC-Final-Crest-Only.png`, 2362px transparent PNG) is the only mark. **No wordmark logo file was provided** — where a lockup is needed, set "Old Penarthians R.F.C" in Old English beside the crest (as the UI kit header does).
- Recommended icon set (substitution, flagged): **Lucide** via CDN (`https://unpkg.com/lucide@latest`) — clean 2px strokes suit Montserrat. Components use minimal unicode glyphs (✕, ✓, ▾, ↓) for built-in affordances only.
- No emoji as icons.

## Index

- `styles.css` — global entry; imports `tokens/` (fonts, colors, typography, spacing, base element styles).
- `assets/` — `OPRFC-Final-Crest-Only.png` (crest), `old-penarthians-team.jpg` (match photo), `fonts/` (Montserrat ×2, Bebas Neue, Old English TTFs).
- `source/` — original brand guidelines PDF.
- `guidelines/` — 16 specimen cards (colors, type, spacing, brand).
- `components/` — **forms/**: Button, IconButton, Input, Select, Checkbox, Radio, Switch · **display/**: Card, Badge, Tag · **navigation/**: Tabs · **feedback/**: Dialog, Toast, Tooltip. Each has `.jsx` + `.d.ts` + `.prompt.md`; one `@dsCard` demo per group.
- `ui_kits/club-site/` — interactive club-website kit (Home / Fixtures / Join).
- `templates/` — starting-point templates: Finance Report, Letterhead, Memo, Meeting Agenda, Meeting Minutes, Email Signature, Certificate. (Invoices excluded — produced directly from Xero.)
- `SKILL.md` — agent skill entry point.

### Intentional additions
- Standard component set (Button → Tooltip): no source defined components, so a baseline set was authored per the guidelines' type/colour rules.
- Semantic color aliases and spacing/radius/shadow scales: not in the guidelines (which cover logo, type, palette only); defined here to make the system usable.

### Caveats
- UI kit screens are original compositions, not recreations of the club website (oldpenarthians.rfc.wales).
- Guidelines call for "Bebas Neue Bold"; only the Regular TTF was provided (Bebas Neue ships one weight) — used as-is.
