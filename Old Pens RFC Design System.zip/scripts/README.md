# Document generators — the ONLY way to produce OPRFC paperwork

Never hand-write .docx XML or HTML for a club document. Write a JSON spec, run the generator. The design lives in code; your job is the content.

## 1. Write the spec
Copy the closest file in `examples/` (memo, letter, agenda, minutes, finance-report) and change the content. Block types:

| type | fields | use |
|---|---|---|
| `meta` | `items: [[label, value], …]` | one row of To/From/Date, Period/Prepared by, etc. |
| `address` | `lines: [...]` | letter recipient |
| `kpis` | `items: [{label, value}]` | 3–4 headline figures (finance) |
| `heading` | `text`, optional `number: false` | section heading — auto-numbered 01, 02… |
| `para` | `text`, optional `bold` | body paragraph |
| `bullets` | `items: [...]` | dash list |
| `table` | `rows`, optional `header`, `total`, `widths` (twips, sum 9638) | last column is right-aligned numeric |
| `action` | `label`, `text` | THE ONE callout panel (Action / FD notes / Decisions). Max one per document. |
| `signoff` | `name`, `role`, `closing` | letter sign-off |
| `spacer` | `pt` | rarely needed |

Top-level: `doc_type` (MEMO / AGENDA / MINUTES / FINANCE REPORT / POLICY — `""` for letters), `title` (the headline; letters: the Re line, with `"title_size": 16`), `crest` (path to `assets/OPRFC-Final-Crest-Only.png` relative to where you run the script).

## 2. Generate
```
pip install python-docx            # once
python scripts/oprfc_docx.py spec.json out.docx     # Word (editable master)
python scripts/oprfc_html.py spec.json out.html     # HTML with embedded fonts → PDF (ALWAYS this route for PDF — never convert the .docx, its fonts/metrics differ):
chromium --headless --disable-gpu --no-pdf-header-footer --print-to-pdf=out.pdf out.html
#   or: weasyprint out.html out.pdf
#   or: soffice --headless --convert-to pdf out.html   (LibreOffice; last resort)
```
Deliver PDF for distribution (fonts travel inside it). Deliver .docx when the user needs to edit — tell them once that it renders in Arial unless Montserrat (in `assets/fonts/`) is installed.

## 3. Check before delivering
- Ran the generator; did not hand-edit the output.
- Exactly one `action` block, or none.
- Headings are short nouns ("Background", "Proposed works") — the generator uppercases and numbers them.
- Money: `£1,234`; negatives `(1,234)`.
- Sign-off role is the real officer (Finance Director, Club Secretary, Chair…).

If the block types genuinely cannot express the document, stop and tell the user what is missing — do not improvise layout.
