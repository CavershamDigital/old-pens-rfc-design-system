#!/usr/bin/env python3
"""OPRFC branded .docx generator — for ANY club document (letters, memos, agendas, minutes, reports, policies).
Usage: python oprfc_docx.py spec.json out.docx   (requires: pip install python-docx)

Spec:
{
  "doc_type": "MEMO" | "FINANCE REPORT" | "MINUTES" | "AGENDA" | "POLICY" | "" (blank for letters),
  "title":    "Pitch maintenance — autumn programme",      # the headline; for letters use the Re: line
  "crest":    "assets/OPRFC-Final-Crest-Only.png",
  "blocks": [
    {"type": "meta",    "items": [["To","All committee"], ["From","Club Secretary"], ["Date","4 September 2026"]]},
    {"type": "address", "lines": ["Mr D. Evans", "12 Plassey Street", "Penarth CF64 1EN"]},   # letters
    {"type": "kpis",    "items": [{"label": "Income", "value": "£9,240"}, ...]},
    {"type": "heading", "text": "Background"},               # auto-numbered 01, 02 … ; "number": false to suppress
    {"type": "para",    "text": "Body paragraph...", "bold": false},
    {"type": "bullets", "items": ["First point", "Second point"]},
    {"type": "table",   "header": ["Item","Amount"], "rows": [["Membership subs","£3,980"]], "total": ["Total income","£9,240"], "widths": [7238,2400]},
    {"type": "action",  "label": "Action", "text": "Committee approval by Friday 12 September."},   # the ONE callout panel
    {"type": "signoff", "name": "Name Surname", "role": "Club Secretary", "closing": "Yours sincerely,"}
  ]
}
Legacy keys (kpis / sections / notes / meta.rows / bar) are still accepted.
All geometry/fonts follow guidelines/document-rules.md — do not modify styling."""
import json, sys
from docx import Document
from docx.shared import Pt, Cm, RGBColor, Twips
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

NAVY, ORANGE, GOLD, INK, MUTED, HAIR, WHITE, GREY = '14274C', 'EC9522', 'FDDA31', '090B0C', '515151', 'E3E3E3', 'FFFFFF', 'F3F3F3'
CONTENT_W = 9638  # twips: A4 11906 - 2*1134

def set_font(run, size, bold=False, color=INK, caps=False, spacing=0):
    run.font.name = 'Montserrat'; run.font.size = Pt(size); run.font.bold = bold
    run.font.color.rgb = RGBColor.from_string(color)
    rpr = run._element.get_or_add_rPr()
    rf = rpr.find(qn('w:rFonts'))
    if rf is None:
        rf = OxmlElement('w:rFonts'); rpr.insert(0, rf)
    for a in ('w:ascii','w:hAnsi','w:cs','w:eastAsia'): rf.set(qn(a), 'Montserrat')
    if caps: rpr.append(OxmlElement('w:caps'))
    if spacing:
        s = OxmlElement('w:spacing'); s.set(qn('w:val'), str(spacing)); rpr.append(s)

def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    sh = OxmlElement('w:shd'); sh.set(qn('w:val'),'clear'); sh.set(qn('w:fill'),fill); tcPr.append(sh)

def no_borders(table):
    tblPr = table._tbl.tblPr
    old = tblPr.find(qn('w:tblBorders'))
    if old is not None: tblPr.remove(old)
    b = OxmlElement('w:tblBorders')
    for edge in ('top','left','bottom','right','insideH','insideV'):
        e = OxmlElement('w:'+edge); e.set(qn('w:val'),'nil'); b.append(e)
    tblPr.append(b)

def fix_width(table, widths, total=None):
    total = total or CONTENT_W
    assert sum(widths) == total, f'widths sum {sum(widths)} != {total}'
    table.autofit = False
    tbl = table._tbl; tblPr = tbl.tblPr
    w = tblPr.find(qn('w:tblW'))
    if w is None:
        w = OxmlElement('w:tblW'); tblPr.append(w)
    w.set(qn('w:w'), str(total)); w.set(qn('w:type'), 'dxa')
    if tblPr.find(qn('w:tblLayout')) is None:
        layout = OxmlElement('w:tblLayout'); layout.set(qn('w:type'), 'fixed')
        tblPr.insert(list(tblPr).index(w) + 1, layout)
    grid = tbl.find(qn('w:tblGrid'))
    for col, width in zip(grid.findall(qn('w:gridCol')), widths): col.set(qn('w:w'), str(width))
    for row in table.rows:
        for i, cell in enumerate(row.cells): cell.width = Twips(widths[i])

def cell_margins(cell, top=113, left=198, bottom=113, right=198):
    tcPr = cell._tc.get_or_add_tcPr()
    m = OxmlElement('w:tcMar')
    for tag, val in (('top',top),('left',left),('bottom',bottom),('right',right)):
        e = OxmlElement('w:'+tag); e.set(qn('w:w'),str(val)); e.set(qn('w:type'),'dxa'); m.append(e)
    tcPr.append(m)

def cell_border(cell, edge, color, sz):
    tcPr = cell._tc.get_or_add_tcPr()
    b = tcPr.find(qn('w:tcBorders'))
    if b is None:
        b = OxmlElement('w:tcBorders'); tcPr.append(b)
    e = OxmlElement('w:'+edge); e.set(qn('w:val'),'single'); e.set(qn('w:sz'),str(sz)); e.set(qn('w:color'),color); b.append(e)

def para_border_bottom(paragraph, color=HAIR, sz=4, space=6):
    pPr = paragraph._element.get_or_add_pPr()
    pbdr = OxmlElement('w:pBdr'); e = OxmlElement('w:bottom')
    e.set(qn('w:val'),'single'); e.set(qn('w:sz'),str(sz)); e.set(qn('w:color'),color); e.set(qn('w:space'),str(space))
    pbdr.append(e); pPr.append(pbdr)

def para(doc, text='', size=10, bold=False, color=INK, before=0, after=8, line=1.5, caps=False, spacing=0):
    p = doc.add_paragraph(); pf = p.paragraph_format
    pf.space_before = Pt(before); pf.space_after = Pt(after); pf.line_spacing = line
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    if text: set_font(p.add_run(text), size, bold, color, caps, spacing)
    return p

def spacer(doc, pt=8):
    p = doc.add_paragraph(); pf = p.paragraph_format
    pf.space_before = Pt(0); pf.space_after = Pt(0); pf.line_spacing = 1.0
    r = p.add_run(''); r.font.size = Pt(pt)
    return p

def keep_next(paragraph):
    paragraph._element.get_or_add_pPr().append(OxmlElement('w:keepNext'))

def styled_fld(paragraph, instr, size, color):
    """Complex field with rPr on every run — fldSimple loses formatting when Word updates the field."""
    def rpr_el():
        rpr = OxmlElement('w:rPr'); rf = OxmlElement('w:rFonts')
        for a in ('w:ascii','w:hAnsi','w:cs','w:eastAsia'): rf.set(qn(a), 'Montserrat')
        rpr.append(rf)
        sz = OxmlElement('w:sz'); sz.set(qn('w:val'), str(int(size*2))); rpr.append(sz)
        cl = OxmlElement('w:color'); cl.set(qn('w:val'), color); rpr.append(cl)
        return rpr
    def fld_run(char_type=None, instr_text=None, result=None):
        r = OxmlElement('w:r'); r.append(rpr_el())
        if char_type:
            fc = OxmlElement('w:fldChar'); fc.set(qn('w:fldCharType'), char_type); r.append(fc)
        if instr_text is not None:
            it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = instr_text; r.append(it)
        if result is not None:
            t = OxmlElement('w:t'); t.text = result; r.append(t)
        return r
    p = paragraph._element
    p.append(fld_run(char_type='begin')); p.append(fld_run(instr_text=f' {instr} \\* MERGEFORMAT '))
    p.append(fld_run(char_type='separate')); p.append(fld_run(result='1')); p.append(fld_run(char_type='end'))

# ---- blocks ----
def block_title(doc, title, px=24):
    para(doc, title, size=round(px * 19 / 24, 1), bold=True, color=NAVY, before=22, after=0, line=1.15)
    # short orange rule: 680 twips wide, 3pt
    t = doc.add_table(rows=1, cols=1); no_borders(t); fix_width(t, [680], 680)
    c = t.rows[0].cells[0]; cell_border(c, 'top', ORANGE, 24); cell_margins(c, 0, 0, 0, 0)
    c.paragraphs[0].paragraph_format.space_before = Pt(8); c.paragraphs[0].paragraph_format.space_after = Pt(0)
    c.paragraphs[0].add_run('').font.size = Pt(2)
    spacer(doc, 6)

def block_meta(doc, items):
    p = para(doc, after=6, line=1.3); para_border_bottom(p, space=8)
    for i, (label, value) in enumerate(items):
        if i: set_font(p.add_run('      '), 9)
        set_font(p.add_run(label.upper() + '  '), 7.5, True, NAVY, spacing=16)
        set_font(p.add_run(value), 9.5, color=MUTED)

def block_address(doc, lines):
    for i, l in enumerate(lines): para(doc, l, after=0, line=1.4, before=(10 if i == 0 else 0))
    spacer(doc, 10)

def block_kpis(doc, items):
    n = len(items); w = [CONTENT_W // n] * n; w[-1] += CONTENT_W - sum(w)
    t = doc.add_table(rows=2, cols=n); no_borders(t); fix_width(t, w)
    for i, k in enumerate(items):
        p = t.rows[0].cells[i].paragraphs[0]; set_font(p.add_run(k['label'].upper()), 7.5, True, MUTED, spacing=16)
        p = t.rows[1].cells[i].paragraphs[0]; set_font(p.add_run(k['value']), 18, True, NAVY)
    spacer(doc, 8)

class Counter:
    n = 0
def block_heading(doc, text, number=True):
    p = para(doc, before=14, after=4, line=1.3); keep_next(p)
    if number:
        Counter.n += 1
        set_font(p.add_run(f'{Counter.n:02d}   '), 9.5, True, ORANGE, spacing=16)
    set_font(p.add_run(text.upper()), 9.5, True, NAVY, spacing=16)

def block_bullets(doc, items):
    for i, it in enumerate(items):
        p = para(doc, '–  ' + it, before=(4 if i == 0 else 0), after=4)
        p.paragraph_format.left_indent = Cm(0.5); p.paragraph_format.first_line_indent = Cm(-0.5)

def block_table(doc, spec_t):
    rows = spec_t['rows']; total = spec_t.get('total'); header = spec_t.get('header')
    ncols = len(rows[0]) if rows else len(header or [])
    widths = spec_t.get('widths')
    if not widths:
        last = 2400; rest = (CONTENT_W - last) // (ncols - 1) if ncols > 1 else CONTENT_W
        widths = [rest] * (ncols - 1) + [last]; widths[0] += CONTENT_W - sum(widths)
    nr = (1 if header else 0) + len(rows) + (1 if total else 0)
    t = doc.add_table(rows=nr, cols=ncols); no_borders(t); fix_width(t, widths)
    ri = 0
    if header:
        for j, h in enumerate(header):
            c = t.rows[0].cells[j]; shade(c, NAVY); cell_margins(c, 90, 120, 90, 120)
            p = c.paragraphs[0]
            if j == ncols - 1: p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            set_font(p.add_run(h.upper()), 7.5, True, WHITE, spacing=12)
        ri = 1
    body = rows + ([total] if total else [])
    for i, row in enumerate(body):
        is_total = bool(total) and i == len(body) - 1
        for j, val in enumerate(row):
            c = t.rows[ri + i].cells[j]; cell_margins(c, 90, 120, 90, 120)
            if not is_total: cell_border(c, 'bottom', HAIR, 4)
            else: cell_border(c, 'top', NAVY, 8)
            p = c.paragraphs[0]; last_col = j == ncols - 1
            if last_col:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
                neg = str(val).strip().startswith('(')
                set_font(p.add_run(val), 10, True, ORANGE if neg else NAVY)
            else:
                set_font(p.add_run(val), 10, is_total, NAVY if is_total else INK)
    spacer(doc, 6)

def block_action(doc, label, text):
    """Callout: light grey panel with a 3pt orange left accent — navy label, ink text."""
    spacer(doc, 10)
    t = doc.add_table(rows=1, cols=2); no_borders(t); fix_width(t, [1400, 8238])
    lc, tc = t.rows[0].cells
    for c in (lc, tc): shade(c, GREY); cell_margins(c, 200, 240, 200, 240)
    cell_border(lc, 'left', ORANGE, 24)
    set_font(lc.paragraphs[0].add_run(label.upper()), 7.5, True, NAVY, spacing=20)
    p = tc.paragraphs[0]; p.paragraph_format.line_spacing = 1.45
    set_font(p.add_run(text), 10, color=INK)
    spacer(doc, 6)

def block_signoff(doc, b):
    para(doc, b.get('closing', 'Yours sincerely,'), before=10, after=0)
    spacer(doc, 26)
    para(doc, b['name'], bold=True, color=NAVY, after=0)
    if b.get('role'): para(doc, b['role'] + ', Old Penarthians RFC', size=9, color=MUTED)

def build(spec, out):
    Counter.n = 0
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Twips(11906), Twips(16838)
    sec.left_margin = sec.right_margin = Twips(1134)
    sec.top_margin = sec.bottom_margin = Twips(907)
    doc.styles['Normal'].font.name = 'Montserrat'
    # Header band: crest | club name (ONE line) | doc type right
    t = doc.add_table(rows=1, cols=3); no_borders(t); fix_width(t, [1300, 5838, 2500])
    for c in t.rows[0].cells: shade(c, NAVY); c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    cell_margins(t.rows[0].cells[0], 150, 240, 150, 120); cell_margins(t.rows[0].cells[1], 150, 120, 150, 120); cell_margins(t.rows[0].cells[2], 150, 120, 150, 240)
    if spec.get('crest'): t.rows[0].cells[0].paragraphs[0].add_run().add_picture(spec['crest'], width=Cm(1.7))
    c2 = t.rows[0].cells[1]
    p = c2.paragraphs[0]; p.paragraph_format.space_after = Pt(0); set_font(p.add_run('OLD PENARTHIANS RFC'), 14, True, WHITE, spacing=12)
    p3 = t.rows[0].cells[2].paragraphs[0]; p3.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    if spec.get('doc_type'): set_font(p3.add_run(spec['doc_type'].upper()), 8.5, True, GOLD, spacing=28)
    if spec.get('title'): block_title(doc, spec['title'], spec.get('title_size', 24))
    else: spacer(doc, 16)
    # Legacy spec -> blocks
    blocks = list(spec.get('blocks', []))
    if not blocks:
        if spec.get('kpis'): blocks.append({'type': 'kpis', 'items': spec['kpis']})
        for s in spec.get('sections', []):
            blocks.append({'type': 'heading', 'text': s['title']})
            if s.get('body'): blocks.append({'type': 'para', 'text': s['body']})
            if s.get('table'): blocks.append({'type': 'table', **s['table']})
        if spec.get('notes'): blocks.append({'type': 'action', 'label': "FD notes", 'text': spec['notes']})
    for b in blocks:
        k = b['type']
        if k == 'meta': block_meta(doc, b.get('items') or b.get('rows'))
        elif k == 'address': block_address(doc, b['lines'])
        elif k == 'kpis': block_kpis(doc, b['items'])
        elif k in ('heading', 'bar'): block_heading(doc, b['text'], b.get('number', True))
        elif k == 'para': para(doc, b['text'], bold=b.get('bold', False), before=2)
        elif k == 'bullets': block_bullets(doc, b['items'])
        elif k == 'table': block_table(doc, b)
        elif k == 'action': block_action(doc, b.get('label', 'Action'), b['text'])
        elif k == 'signoff': block_signoff(doc, b)
        elif k == 'spacer': spacer(doc, b.get('pt', 10))
        else: raise ValueError('unknown block type: ' + k)
    # Footer: 2-cell table, two planned lines per side, shared orange top rule
    ft = sec.footer.add_table(rows=1, cols=2, width=Twips(CONTENT_W)); no_borders(ft); fix_width(ft, [4200, 5438])
    for c in ft.rows[0].cells: cell_border(c, 'top', ORANGE, 16); cell_margins(c, 90, 0, 0, 0)
    lp = ft.rows[0].cells[0].paragraphs[0]; lp.paragraph_format.space_after = Pt(1)
    set_font(lp.add_run('Old Penarthians RFC Ltd. | Company No. 11879102'), 6.5, color=MUTED)
    lp2 = ft.rows[0].cells[0].add_paragraph()
    set_font(lp2.add_run('Page '), 6.5, color=MUTED); styled_fld(lp2, 'PAGE', 6.5, MUTED)
    set_font(lp2.add_run(' of '), 6.5, color=MUTED); styled_fld(lp2, 'NUMPAGES', 6.5, MUTED)
    rc = ft.rows[0].cells[1]
    rp = rc.paragraphs[0]; rp.alignment = WD_ALIGN_PARAGRAPH.RIGHT; rp.paragraph_format.space_after = Pt(1)
    set_font(rp.add_run('Cwrt-y-Vil Playing Fields, St. Marks Road, Penarth CF64 3PF'), 6.5, color=MUTED)
    rp2 = rc.add_paragraph(); rp2.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    set_font(rp2.add_run('info@oldpens.wales · oldpenarthians.rfc.wales'), 6.5, color=MUTED)
    fp0 = sec.footer.paragraphs[0]; fp0._element.getparent().remove(fp0._element)
    doc.save(out)
    add_font_fallback(out)

def add_font_fallback(path):
    """Register Arial as Montserrat's altName so machines without Montserrat fall back to a clean sans, not Times."""
    import zipfile
    with zipfile.ZipFile(path) as z: items = {n: z.read(n) for n in z.namelist()}
    ft = items['word/fontTable.xml'].decode('utf-8')
    entry = '<w:font w:name="Montserrat"><w:altName w:val="Arial"/><w:family w:val="swiss"/><w:pitch w:val="variable"/></w:font>'
    if 'w:name="Montserrat"' in ft: ft = ft.replace('<w:font w:name="Montserrat">', '<w:font w:name="Montserrat"><w:altName w:val="Arial"/>', 1)
    else: ft = ft.replace('</w:fonts>', entry + '</w:fonts>')
    items['word/fontTable.xml'] = ft.encode('utf-8')
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for n, data in items.items(): z.writestr(n, data)

if __name__ == '__main__':
    spec = json.load(open(sys.argv[1]))
    out = sys.argv[2] if len(sys.argv) > 2 else 'out.docx'
    build(spec, out); print('wrote', out)
