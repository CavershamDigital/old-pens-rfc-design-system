#!/usr/bin/env python3
"""OPRFC branded HTML generator (for PDF). Same JSON spec as oprfc_docx.py.
Usage: python oprfc_html.py spec.json out.html
Then PDF (pick whichever exists):
  chrome/chromium:  chromium --headless --disable-gpu --no-pdf-header-footer --print-to-pdf=out.pdf out.html
  playwright:       python -c "from playwright.sync_api import sync_playwright as p; b=p().start().chromium.launch(); pg=b.new_page(); pg.goto('file://'+__import__('os').path.abspath('out.html')); pg.pdf(path='out.pdf', format='A4', print_background=True, prefer_css_page_size=True)"
  weasyprint:       weasyprint out.html out.pdf
Fonts are embedded via @font-face from the skill's assets/fonts/ (path resolved relative to this script)."""
import json, sys, os, html

NAVY, ORANGE, GOLD, INK, MUTED, HAIR, GREY = '#14274C', '#EC9522', '#FDDA31', '#090B0C', '#515151', '#E3E3E3', '#F3F3F3'
HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.abspath(os.path.join(HERE, '..', 'assets'))
E = html.escape

def label(t): return f'<strong style="font-weight:700;color:{NAVY};font-size:9px;letter-spacing:.08em">{E(t.upper())}</strong>'

def render(spec):
    font = 'file://' + os.path.join(ASSETS, 'fonts', 'Montserrat-VariableFont_wght.ttf')
    crest = 'file://' + os.path.join(ASSETS, 'OPRFC-Final-Crest-Only.png')
    out = []
    n = 0
    for b in spec.get('blocks', []):
        k = b['type']
        if k == 'meta':
            items = b.get('items') or b.get('rows')
            out.append(f'<div style="display:flex;flex-wrap:wrap;gap:10px 28px;font-size:10.5px;font-weight:300;color:{MUTED};padding-bottom:16px;border-bottom:1px solid {HAIR}">' + ''.join(f'<span>{label(l)}&nbsp;&nbsp;{E(v)}</span>' for l, v in items) + '</div><div style="height:20px"></div>')
        elif k == 'address':
            out.append('<div style="line-height:1.5;margin-bottom:18px">' + ''.join(f'<div>{E(l)}</div>' for l in b['lines']) + '</div>')
        elif k == 'kpis':
            out.append(f'<div style="display:grid;grid-template-columns:repeat({len(b["items"])},1fr);margin:2px 0 24px">' + ''.join(f'<div><div style="font-weight:700;font-size:9px;letter-spacing:.1em;color:{MUTED}">{E(i["label"].upper())}</div><div style="font-weight:700;font-size:26px;color:{NAVY};margin-top:4px">{E(i["value"])}</div></div>' for i in b['items']) + '</div>')
        elif k in ('heading', 'bar'):
            num = ''
            if b.get('number', True):
                n += 1; num = f'<span style="color:{ORANGE}">{n:02d}</span>'
            out.append(f'<div style="font-weight:700;font-size:10.5px;letter-spacing:.1em;color:{NAVY};margin:18px 0 6px;display:flex;align-items:center;gap:10px;break-after:avoid">{num}{E(b["text"].upper())}</div>')
        elif k == 'para':
            w = 'font-weight:600;color:' + NAVY + ';' if b.get('bold') else ''
            out.append(f'<p style="margin:0 0 10px;{w}">{E(b["text"])}</p>')
        elif k == 'bullets':
            out.append(''.join(f'<p style="margin:0 0 4px 14px;text-indent:-14px">–&nbsp;&nbsp;{E(i)}</p>' for i in b['items']) + '<div style="height:6px"></div>')
        elif k == 'table':
            rows = b['rows']; total = b.get('total'); header = b.get('header'); nc = len(rows[0]) if rows else len(header)
            h = ''
            if header:
                h = '<thead><tr style="background:' + NAVY + ';color:#fff;font-size:9px;letter-spacing:.08em">' + ''.join(f'<th style="padding:7px 12px;text-align:{"right" if j == nc-1 else "left"};font-weight:700">{E(x.upper())}</th>' for j, x in enumerate(header)) + '</tr></thead>'
            def cell(v, j, tot):
                last = j == nc - 1
                if last:
                    neg = str(v).strip().startswith('(')
                    return f'<td style="padding:8px 12px;text-align:right;font-weight:700;color:{ORANGE if neg else NAVY}">{E(v)}</td>'
                return f'<td style="padding:8px 12px;{"font-weight:700;color:"+NAVY if tot else ""}">{E(v)}</td>'
            body = ''.join(f'<tr style="border-bottom:1px solid {HAIR}">' + ''.join(cell(v, j, False) for j, v in enumerate(r)) + '</tr>' for r in rows)
            if total: body += f'<tr style="border-top:2px solid {NAVY}">' + ''.join(cell(v, j, True) for j, v in enumerate(total)) + '</tr>'
            out.append(f'<table style="width:100%;border-collapse:collapse;font-size:11.5px;margin-bottom:6px">{h}<tbody>{body}</tbody></table>')
        elif k == 'action':
            out.append(f'<div style="margin-top:22px;background:{GREY};border-left:3px solid {ORANGE};padding:14px 18px;display:grid;grid-template-columns:auto 1fr;gap:18px;align-items:start;break-inside:avoid"><div style="font-weight:700;font-size:9.5px;letter-spacing:.12em;color:{NAVY};padding-top:3px;white-space:nowrap">{E(b.get("label","Action").upper())}</div><div style="font-weight:300;font-size:11.5px;line-height:1.6;color:{INK}">{E(b["text"])}</div></div>')
        elif k == 'signoff':
            out.append(f'<div style="margin-top:22px">{E(b.get("closing","Yours sincerely,"))}</div><div style="font-weight:700;color:{NAVY};margin-top:44px">{E(b["name"])}</div>' + (f'<div style="font-size:10px;color:{MUTED}">{E(b["role"])}, Old Penarthians RFC</div>' if b.get('role') else ''))
        elif k == 'spacer':
            out.append(f'<div style="height:{b.get("pt",10)*1.33:.0f}px"></div>')
        else:
            raise ValueError('unknown block type: ' + k)
    body = ''.join(out)
    doc_type = f'<div style="font-weight:600;font-size:10px;letter-spacing:.14em;color:{GOLD}">{E(spec["doc_type"].upper())}</div>' if spec.get('doc_type') else ''
    title = ''
    if spec.get('title'):
        size = spec.get('title_size', 24)
        title = f'<div style="font-weight:700;font-size:{size}px;line-height:1.2;color:{NAVY};max-width:32ch">{E(spec["title"])}</div><div style="width:48px;height:3px;background:{ORANGE};margin:14px 0"></div>'
    return f'''<!DOCTYPE html><html><head><meta charset="utf-8"><title>{E(spec.get("title") or spec.get("doc_type") or "OPRFC")}</title>
<style>
@font-face{{font-family:Montserrat;src:url("{font}") format("truetype");font-weight:100 900}}
@page{{size:A4;margin:0}}
html,body{{margin:0;padding:0}}
body{{font-family:Montserrat,Arial,sans-serif;color:{INK};-webkit-print-color-adjust:exact;print-color-adjust:exact}}
.page{{width:794px;min-height:1123px;margin:0 auto;background:#fff;display:flex;flex-direction:column}}
.content{{padding:34px 56px 0;flex:1;font-weight:300;font-size:11.5px;line-height:1.7}}
.footer{{margin-top:32px;padding:12px 56px 40px;border-top:2px solid {ORANGE};display:flex;justify-content:space-between;font-weight:300;font-size:8.5px;line-height:1.6;color:{MUTED}}}
@media print{{.page{{min-height:auto}}.footer{{position:fixed;bottom:0;left:0;right:0;background:#fff}}.content{{padding-bottom:90px}}}}
</style></head><body><div class="page">
<div style="background:{NAVY};padding:18px 56px;display:flex;align-items:center;justify-content:space-between"><div style="display:flex;align-items:center;gap:16px"><img src="{crest}" alt="" style="width:64px;height:64px"><div style="font-weight:700;font-size:17px;letter-spacing:.04em;color:#fff;white-space:nowrap">OLD PENARTHIANS RFC</div></div>{doc_type}</div>
<div class="content">{title}{body}</div>
<div class="footer"><div><div>Old Penarthians RFC Ltd. | Company No. 11879102</div><div>oldpenarthians.rfc.wales</div></div><div style="text-align:right"><div>Cwrt-y-Vil Playing Fields, St. Marks Road, Penarth CF64 3PF</div><div>info@oldpens.wales</div></div></div>
</div></body></html>'''

if __name__ == '__main__':
    spec = json.load(open(sys.argv[1]))
    out = sys.argv[2] if len(sys.argv) > 2 else 'out.html'
    open(out, 'w', encoding='utf-8').write(render(spec)); print('wrote', out)
