---
name: old-pens-rfc-design
description: Produce on-brand Old Penarthians RFC (Old Pens / OPRFC) output — club paperwork as Word/PDF (letters, memos, agendas, minutes, finance reports, policies), plus web/UI, slides and assets. Use for any OPRFC document or "on-brand" request from any committee or board member.
user-invocable: true
---

# Old Pens RFC design skill

## Documents (letters, memos, agendas, minutes, reports, policies) — 90% of requests

**Do not design. Generate.** The document design is fixed and implemented in code. Your only creative input is the content.

1. Read `scripts/README.md` (2 minutes).
2. Copy the closest spec from `scripts/examples/` and replace the content with the user's.
3. Run `scripts/oprfc_docx.py` for Word and `scripts/oprfc_html.py` → PDF (PDF ALWAYS comes from the HTML generator, never by converting the .docx). Deliver the real files.
4. Do NOT hand-write .docx XML, python-docx code, HTML, or CSS for a document. Do NOT add sections, boxes, colours, fonts or logos that the generator doesn't produce. Do NOT "improve" the layout. If the spec's block types can't express what's needed, say so and ask — never improvise.

Why this is strict: every hand-built attempt has drifted from the brand (wrong fonts, centered crests, navy slabs, broken footers). The generator is the brand.

`guidelines/document-rules.md` describes the grammar the generators implement — read it only if you must reason about the design (e.g. the user asks *why*). `guidelines/output-formats.md` has Word/PDF conversion detail and fallbacks.

## Everything else (web, UI, slides, social, signage)
Read `readme.md` for the brand: palette, Montserrat (documents) / Bebas Neue (display headlines only, never in documents), tone of voice, crest usage. Tokens are in `styles.css` + `tokens/`; the crest is `assets/OPRFC-Final-Crest-Only.png`; templates in `templates/` show the look. Use the same grammar where it applies: navy `#14274C` as the base, orange `#EC9522` as the single accent, gold `#FDDA31` for small labels on navy, Montserrat 300 body / 700 headings, left-aligned, no boxes or gradients.

If invoked with no brief, ask what they need to produce and for whom, then act.
