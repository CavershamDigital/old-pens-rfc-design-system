# OPRFC Document Layout Rules — MANDATORY

These rules are NOT suggestions. Any A4 document (policy, letter, memo, report, agenda, minutes) MUST follow this grammar. When in doubt, copy the matching file in `templates/` verbatim and change only the content. For Word output, `scripts/oprfc_docx.py` implements every rule below — use it.

## The grammar (top to bottom)

1. **Header band** — ONE navy (`#14274C`) band, full page width, slim (18px vertical padding). Left: crest (64px) then the club name on ONE line, "OLD PENARTHIANS RFC", white 700-weight 17px, letter-spacing 0.04em, never wrapped. Right: the document type ("MEMO", "AGENDA", "MINUTES", "FINANCE REPORT") in gold `#FDDA31`, 600-weight 10px, letter-spacing 0.14em. Letters have no document-type label. **Nothing else goes in the band** — no address, no italics, no subtitle.
2. **Headline** — the subject IS the title: navy 700-weight 24px (16px on letters, where it follows the salutation as the "Re" line), max ~32ch, left-aligned. Under it a **short orange rule**: 48×3px `#EC9522`.
3. **Meta line** — ONE row of label/value pairs separated by 28px gaps, under the rule, closed by a 1px `#E3E3E3` hairline. Labels navy 700 9px letter-spaced caps (TO, FROM, DATE / DATE, TIME, VENUE, CHAIR / PERIOD, PREPARED BY). Values 300-weight 10.5px `#515151`. Never a stacked form of full-width rows.
4. **KPI strip (finance only)** — 4 equal columns, borderless: label 700 9px caps grey, value 700 26px navy. No boxes, no borders, no colored edges.
5. **Section headings** — typographic, NOT slabs: an orange two-digit numeral (`01`, `02`…) then the heading in navy 700 10.5px UPPERCASE, letter-spacing 0.1em. 18px above, 6px below. Must never sit at the bottom of a page with no text under it (Word `keepNext`; CSS `break-after: avoid`).
6. **Body** — Montserrat 300, 11.5px, line-height 1.7, `#090B0C`, left-aligned. Bullets are an en-dash `–` with hanging indent. Inline emphasis: 600-weight navy.
7. **Tables** — header row navy bg, white 700 9px caps (agenda/minutes/finance). Body rows: 1px `#E3E3E3` bottom hairline only, no side borders. Last column right-aligned, navy 700. Total row: 2px navy top border, navy bold. Negatives orange, parenthesised.
8. **The callout panel** — exactly ONE per document, reserved for the thing that matters most: the Action (memo), FD Notes (finance report). Light grey `#F3F3F3` background with a 3px orange `#EC9522` left accent, 14px 18px padding; navy 700 letter-spaced label on the left (ACTION / FD NOTES), ink 300 11.5px text on the right. Never use it for ordinary sections; never make it navy.
9. **Footer** — 2px `#EC9522` top rule, then TWO planned lines per side, Montserrat 300 8.5px `#515151`. Left: `Old Penarthians RFC Ltd. | Company No. 11879102` / `Page N of M`. Right (right-aligned): `Cwrt-y-Vil Playing Fields, St. Marks Road, Penarth CF64 3PF` / `info@oldpens.wales · oldpenarthians.rfc.wales`. Never let it wrap organically.

## Hard prohibitions
- No full-width navy bars as section headings (the old grammar). Navy fills are only the header band and table header rows.
- No boxes, cards, rounded corners, or coloured borders — the single callout panel (rule 8) is the only exception.
- No centered text (certificates excepted). No italics.
- Montserrat only — never Bebas Neue or any display face in documents. Weights: 300 body, 600 emphasis, 700 headings/labels.
- Colors ONLY: navy `#14274C`, orange `#EC9522`, gold `#FDDA31`, ink `#090B0C`, muted `#515151`, hairline `#E3E3E3`, white. No `#24599D` blue in documents.

## Canonical markup (HTML → PDF route)

Header band:
```html
<div style="background:#14274C;padding:18px 56px;display:flex;align-items:center;justify-content:space-between">
  <div style="display:flex;align-items:center;gap:16px"><img src="assets/OPRFC-Final-Crest-Only.png" style="width:64px;height:64px"><div style="font-weight:700;font-size:17px;letter-spacing:.04em;color:#fff;white-space:nowrap">OLD PENARTHIANS RFC</div></div>
  <div style="font-weight:600;font-size:10px;letter-spacing:.14em;color:#FDDA31">MEMO</div>
</div>
```
Headline + rule + meta:
```html
<div style="font-weight:700;font-size:24px;line-height:1.2;color:#14274C;max-width:32ch">Subject line</div>
<div style="width:48px;height:3px;background:#EC9522;margin:14px 0"></div>
<div style="display:flex;gap:28px;font-size:10.5px;font-weight:300;color:#515151;padding-bottom:16px;border-bottom:1px solid #E3E3E3"><span><strong style="font-weight:700;color:#14274C;font-size:9px;letter-spacing:.08em">TO</strong>&nbsp;&nbsp;All committee members</span> …</div>
```
Section heading:
```html
<div style="font-weight:700;font-size:10.5px;letter-spacing:.1em;color:#14274C;margin:18px 0 6px;display:flex;gap:10px;break-after:avoid"><span style="color:#EC9522">01</span>BACKGROUND</div>
```
Callout panel:
```html
<div style="margin-top:22px;background:#F3F3F3;border-left:3px solid #EC9522;padding:14px 18px;display:grid;grid-template-columns:auto 1fr;gap:18px"><div style="font-weight:700;font-size:9.5px;letter-spacing:.12em;color:#14274C;padding-top:3px">ACTION</div><div style="font-weight:300;font-size:11.5px;line-height:1.6;color:#090B0C">…</div></div>
```
Footer:
```html
<div style="margin-top:32px;padding:12px 56px 40px;border-top:2px solid #EC9522;display:flex;justify-content:space-between;font-weight:300;font-size:8.5px;line-height:1.6;color:#515151"><div><div>Old Penarthians RFC Ltd. | Company No. 11879102</div><div>Page 1 of 1</div></div><div style="text-align:right"><div>Cwrt-y-Vil Playing Fields, St. Marks Road, Penarth CF64 3PF</div><div>info@oldpens.wales · oldpenarthians.rfc.wales</div></div></div>
```

## Page geometry
A4 white, 56px side padding on content (Word: 2cm margins, content width 9638 twips). Header band spans full page width. 34px between band and headline; 20px between meta hairline and first section.

## Workflow
Open the matching `templates/` file first (letterhead, memo, meeting-agenda, meeting-minutes, finance-report). Reuse its markup; change only content. For Word, write the JSON spec and run `scripts/oprfc_docx.py`.
