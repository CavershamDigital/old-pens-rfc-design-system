# Producing Word (.docx) and PDF output

The templates in `templates/` are HTML — the visual source of truth. When the user needs a real file (Word or PDF), convert as follows. Layout rules in `document-rules.md` apply identically to every format.

## PDF (preferred for finished paperwork: policies, reports, minutes, certificates)

**Route 1 — HTML → PDF (best fidelity).** Generate the HTML with `scripts/oprfc_html.py spec.json out.html` (same JSON spec as the Word generator; fonts embedded from `assets/fonts/`), then convert:
- With browser tooling available (Playwright/Chromium): `page.pdf({format: 'A4', printBackground: true})` — `printBackground: true` is required or the navy bands disappear.
- With weasyprint: `weasyprint doc.html doc.pdf`.
- Add this to the HTML for print: `@page { size: A4; margin: 0 }` and give the body the 48px side padding itself.
- Fonts: embed Montserrat via `@font-face` pointing at `assets/fonts/` (copy the TTFs next to the HTML), or a Google Fonts `<link>` if network is allowed.

**Route 2 — reportlab (no HTML step).** Only if no HTML→PDF converter exists. Reproduce the grammar exactly: navy `#14274C` header band with crest image left, gold subtitle, navy section bars, 2px orange footer rule. Register Montserrat TTFs from `assets/fonts/` with `pdfmetrics.registerFont`.

## Word (.docx) — when the user must edit the document afterwards

Use the bundled generator **`scripts/oprfc_docx.py`** for EVERY .docx — letters, memos, agendas, minutes, reports, policies, any committee/board paperwork. Write a JSON spec: `doc_type`, `title` (the headline), and typed blocks (`meta`, `address`, `kpis`, `heading`, `para`, `bullets`, `table`, `action`, `signoff` — full format in the script's docstring) and run it; it encodes every rule below (Montserrat-only fonts, 9638-twip tables, slim 3-cell header band, headline + orange rule, inline meta line, typographic numbered headings with keepNext, borderless KPI strip, the single grey/orange callout panel, two-line table footer with styled page fields). Only hand-build python-docx when the block types genuinely can't express the document — and then obey these rules exactly. **The rules below are strict — each one exists because violating it has produced broken documents.**

### Font rules (the #1 failure mode)
- **Word never embeds these fonts** — a .docx looks right only on machines with Montserrat installed. Tell the user ONCE per session if relevant: install the TTFs from `assets/fonts/` (Mac: Font Book → drag in; Windows: right-click → Install). **For distribution to others, always deliver a PDF** (fonts embed automatically); the .docx is the editable master for people with the fonts.
- The ONLY font family name allowed anywhere in a .docx is **`Montserrat`** — never `Montserrat Light`, `Montserrat SemiBold`, `Montserrat Medium`, `Bebas Neue`, or any other variant/display name. Variant names are separate families in Word: on any machine without that exact variant installed, Word silently substitutes Times New Roman and the document collapses.
- Express weight ONLY via the bold flag: normal runs = `Montserrat` regular; emphasis/labels/headings = `Montserrat` + `bold=True`. No light, no semibold, no display faces.
- Set the document default once and verify every run inherits or restates it: `styles['Normal'].font.name = 'Montserrat'` plus the `w:eastAsia`/`w:cs`/`w:hAnsi` attributes.
- Numbers (KPI values, totals) use Montserrat bold — NEVER Bebas Neue or any display face in Word output.

### Geometry rules (the #2 failure mode)
- **Page**: A4 = 11906×16838 twips. Margins 1134 twips (2cm) left/right, 907 twips (1.6cm) top/bottom. **Content width is therefore exactly 9638 twips — every table's `tblGrid` columns MUST sum to 9638.** A table wider than that overflows the margins and looks broken. Never use `w:tblW type="auto" w="0"` with fixed layout; set `tblW` to 9638 dxa explicitly.
- Header band: 3 columns, **exactly 1300 + 5838 + 2500 = 9638** (crest | "OLD PENARTHIANS RFC" on ONE line at 14pt | doc type right-aligned gold 8.5pt bold) — the crest cell is narrow, the crest sits snug beside the club name. A wider crest cell (e.g. 50/50) is wrong. Set `w:tblCellSpacing` to 0 so no seam shows between the two navy cells. KPI strip: 4 × 2409 or 2410 (sum 9638). Section bars and finance tables: full 9638.
- **The doc-type line must never wrap.** If it's long, reduce letter-spacing first, then font size (min 8pt) — one line always.

### Structure rules
- **Header band**: a 1-row, 3-cell borderless table, shading `14274C` on all cells. Cell 1: crest at 1.7cm. Cell 2: "OLD PENARTHIANS RFC" on one line, Montserrat bold 14pt white. Cell 3: doc type right-aligned, bold 8.5pt gold `FDDA31`, letter-spaced, vertically centred. **Nothing else** — no address, no italics.
- **Headline**: the subject as Montserrat bold 20pt navy, then a 680-twip-wide 3pt orange rule (a 1-cell table with top border). Then the **meta line**: one paragraph of label/value runs (label bold 7.5pt navy caps, value 9.5pt `515151`) with a hairline bottom border.
- **Body text**: Montserrat regular 10pt, color `090B0C`, line spacing 1.5, left-aligned.
- **Section headings**: typographic, not slabs — orange two-digit numeral + navy bold 9.5pt UPPERCASE letter-spaced, 14pt above / 4pt below, `keepNext`. Never navy bars, never Heading styles.
- **Callout panel**: exactly one per document (Action / FD Notes): 2-cell table [1400, 8238] shaded `F3F3F3` with a 3pt orange left border on the first cell; navy bold label left, ink 10pt text right. Never navy.
- **KPI strip (finance reports)**: a single 2-row borderless table — row 1 labels (Montserrat bold 8pt caps `515151`), row 2 values (Montserrat bold 16pt `14274C`). **No cell borders, no colored top edges, no box outlines** — decorative boxes are banned by document-rules.md rule 4. Whitespace separates the KPIs.
- **Tables (finance)**: header row shaded `14274C` white bold 8pt caps; body rows bottom border `E3E3E3` 0.5pt only (no side borders); numeric cells right-aligned, navy `14274C`, bold. Negatives in orange `EC9522`, parenthesised: `(1,234)`.
- **Footer** (real Word footer so it repeats per page): a 2-cell borderless table with a shared orange `EC9522` 2px top border — NEVER a tab-stop layout. **Planned as exactly two lines per side**: left = legal text, then `Page X of Y` (complex fields with rPr on every run + `\* MERGEFORMAT`); right (right-aligned) = address line, then `info@oldpens.wales · oldpenarthians.rfc.wales`. Never let footer text wrap organically — if content changes, re-plan the line breaks.
- **Vertical rhythm**: every section heading gets the same fixed gap above it (14pt) whatever precedes it. Never use default empty paragraphs as spacing — they're 10pt × 1.5 line-height and make gaps inconsistent; use a fixed-height spacer (empty run at the gap size, line-spacing 1.0).
- **Section headings must carry `keepNext`** so a heading is never orphaned at the bottom of a page.
- **Colors**: ONLY `14274C` `EC9522` `FDDA31` `090B0C` `515151` `E3E3E3` `FFFFFF`. The web palette's blue `24599D` is NOT allowed in documents.

## Finance reports specifically

Follow `templates/finance-report/` structure: header band → headline ("Finance report — September 2026") + rule → meta (Period / Prepared by / For) → KPI strip → numbered headings with tables → the callout panel labelled FD NOTES → footer. Sign-off is always **Finance Director** (not Treasurer). GBP with thousands separators, no decimals for whole pounds: `£12,450`.

## Other document types (any officer)

Every committee/board document uses the same grammar via generator blocks:
- **Letter**: `doc_type` "" → `address` → `para` date → `para` salutation → `title` is the Re line → `para` body → `signoff`.
- **Memo**: `doc_type` MEMO, `title` = subject → `meta` (To/From/Date) → `heading`+`para`/`bullets` sections → one `action`.
- **Agenda**: `doc_type` AGENDA, `title` = meeting → `meta` (Date/Time/Venue/Chair) → `table` header [#, Item, Lead, Mins].
- **Minutes**: `doc_type` MINUTES → `meta` (Venue/Time/Present/Apologies) → numbered `heading`+`para` per item → `heading` "Action log" (`number: false`) + `table` [Action, Owner, Due].
- **Policy/report**: numbered `heading` + `para`/`bullets` → optional `signoff`.
Match the corresponding `templates/` HTML file for wording and structure.

## Checklist before delivering any file
- [ ] The .docx was produced by `scripts/oprfc_docx.py` — if you hand-built it instead, say so and why
- [ ] Header band 1300/5838/2500; club name on ONE line; doc type right in gold; headline + orange rule beneath
- [ ] Every font name in the file is exactly `Montserrat` — grep the produced document.xml for `w:ascii=` and verify; any variant name or display face = redo
- [ ] Every `tblGrid` sums to exactly 9638 twips (A4, 2cm margins)
- [ ] Navy bands print/export with their background (no white gaps)
- [ ] Crest inside the band, left; no address/italic line in the band
- [ ] Section headings are typographic (orange numeral + navy caps), NOT navy bars; exactly one grey callout panel
- [ ] Only the 7 document colors; no `24599D` blue
- [ ] Everything left-aligned (except certificates)
- [ ] No section bar orphaned at a page bottom; page numbers match their line's size
- [ ] Consistent gap above every heading; no default empty paragraphs as spacers
- [ ] Footer is two planned lines per side (legal / page — address / email·web); nothing wraps organically
- [ ] Montserrat embedded (PDF) or set as document default (Word)
