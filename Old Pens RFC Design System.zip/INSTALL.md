# Installing the Old Pens RFC Design System

This folder is a self-contained brand & design system for Old Penarthians RFC. Any AI assistant can use it to produce on-brand documents (Word/PDF), web pages and assets.

## How it works
The document design is **fixed and implemented in code**: the AI writes a small JSON description of your content (see `scripts/examples/`), runs `scripts/oprfc_docx.py` (Word) or `scripts/oprfc_html.py` (→ PDF), and every letter, memo, agenda, set of minutes, or finance report comes out identical in layout. This is what stops different AIs — or the same AI on different days — producing different designs.

## Install

**Claude Code / Claude Desktop** — unzip into `~/.claude/skills/old-pens-rfc-design/` (delete any older copy first). Claude auto-discovers `SKILL.md`. Then ask e.g. "Write a memo to the committee about pitch maintenance, as Word and PDF."

**Claude.ai (web)** — create a Project; upload `SKILL.md`, `readme.md`, `scripts/` (all files), `guidelines/document-rules.md`, `guidelines/output-formats.md`, `assets/OPRFC-Final-Crest-Only.png` and `assets/fonts/Montserrat-VariableFont_wght.ttf` to Project Knowledge. Project instruction: "Follow SKILL.md. For documents, always generate via scripts/oprfc_docx.py or oprfc_html.py — never hand-build."

**ChatGPT** — create a Project or custom GPT; upload the same files. Same instruction. (ChatGPT's code tool has python-docx; it can run the generators directly.)

**Any other AI with a code tool** — give it the `scripts/` folder, the crest, and `SKILL.md`. Without a code tool, give it `guidelines/document-rules.md` and `templates/` and accept that fidelity will be lower.

## Fonts
Word files render in Montserrat only if it's installed. Install once from `assets/fonts/` (Mac: Font Book → drag in; Windows: right-click → Install). PDFs embed the font and need nothing.

**Recommended:** the bundled Montserrat is the *variable* TTF; Word fakes its bold from that and it comes out too heavy. Download the Montserrat family from fonts.google.com and add the `static/` files `Montserrat-Light.ttf`, `Montserrat-Regular.ttf`, `Montserrat-SemiBold.ttf`, `Montserrat-Bold.ttf` to `assets/fonts/` and install those — Word will then use the true Bold.

## What's inside
- `SKILL.md` — instructions for the AI (start here)
- `scripts/` — the document generators + example specs + README
- `readme.md` — brand rulebook (palette, type, tone, iconography)
- `guidelines/` — document grammar, output-format detail, specimen cards
- `templates/` — HTML reference versions of each document type
- `assets/` — crest, fonts, imagery · `styles.css` + `tokens/` — CSS variables · `components/`, `ui_kits/` — web UI

Invoices are NOT covered — they come directly from Xero.
